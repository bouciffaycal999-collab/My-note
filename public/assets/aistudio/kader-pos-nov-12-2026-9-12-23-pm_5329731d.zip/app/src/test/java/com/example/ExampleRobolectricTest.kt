package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Kader POS", appName)
  }

  @Test
  fun `catalog seed asset parses cleanly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val raw = context.assets.open("catalog_seed.json").bufferedReader().use { it.readText() }
    val arr = JSONArray(raw)
    assertTrue("Expected seeded ceramic catalog items", arr.length() > 300)
  }
}
