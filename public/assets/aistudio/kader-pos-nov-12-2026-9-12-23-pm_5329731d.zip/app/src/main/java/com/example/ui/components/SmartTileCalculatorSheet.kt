package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CalcInputMode
import com.example.data.model.CartItem
import com.example.data.model.FreeLineItem
import com.example.data.model.TileCalculatorMath
import com.example.data.model.TileProduct
import com.example.data.model.formatDa
import com.example.data.model.formatM2
import com.example.ui.theme.Amber300
import com.example.ui.theme.Amber400
import com.example.ui.theme.Amber500
import com.example.ui.theme.Amber950
import com.example.ui.theme.Cyan300
import com.example.ui.theme.Cyan400
import com.example.ui.theme.Cyan500
import com.example.ui.theme.Cyan950
import com.example.ui.theme.Emerald300
import com.example.ui.theme.Emerald400
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Emerald950
import com.example.ui.theme.Rose400
import com.example.ui.theme.Rose950
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate850
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import java.util.UUID

private enum class CalcFieldTarget(val allowDecimal: Boolean) {
    SURFACE(true),
    LENGTH(true),
    WIDTH(true),
    CARTONS(false),
    PIECES(false),
    COLISAGE_M2(true),
    PCS_PER_CARTON(false),
    PRICE_PER_M2(true)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartTileCalculatorSheet(
    product: TileProduct?,
    editingCartItem: CartItem?,
    onDismiss: () -> Unit,
    onConfirmProductCart: (
        product: TileProduct,
        cartons: Int,
        pieces: Int,
        m2Total: Double,
        prixPerM2: Double,
        bain: String,
        calibre: String,
        editingItemId: String?
    ) -> Unit,
    onConfirmStandaloneFreeLine: (FreeLineItem) -> Unit
) {
    BackHandler { onDismiss() }

    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val isTileBound = product != null || editingCartItem != null

    var mode by remember {
        mutableStateOf(if (editingCartItem != null) CalcInputMode.CARTONS_PIECES else CalcInputMode.SURFACE)
    }
    var marginPercent by remember { mutableIntStateOf(0) }

    var surfaceStr by remember {
        mutableStateOf(
            if (editingCartItem != null) formatM2(editingCartItem.m2Total)
            else "20"
        )
    }
    var lengthStr by remember { mutableStateOf("5") }
    var widthStr by remember { mutableStateOf("4") }
    var cartonsStr by remember {
        mutableStateOf((editingCartItem?.cartons ?: 1).toString())
    }
    var piecesStr by remember {
        mutableStateOf((editingCartItem?.pieces ?: 0).toString())
    }
    var colisageM2Str by remember {
        mutableStateOf(
            formatM2(editingCartItem?.m2Carton ?: product?.m2Carton ?: 1.44)
        )
    }
    var pcsPerCartonStr by remember {
        mutableStateOf((editingCartItem?.pcs ?: product?.pcs ?: 4).toString())
    }
    var pricePerM2Str by remember {
        val initialPrix = editingCartItem?.prixUnitaire ?: product?.prix ?: 1200.0
        mutableStateOf(
            if (initialPrix % 1.0 == 0.0) initialPrix.toInt().toString() else initialPrix.toString()
        )
    }

    var bainNote by remember { mutableStateOf(editingCartItem?.bain ?: "") }
    var calibreNote by remember { mutableStateOf(editingCartItem?.calibre ?: "") }

    var activeField by remember {
        mutableStateOf(
            if (editingCartItem != null) CalcFieldTarget.CARTONS else CalcFieldTarget.SURFACE
        )
    }
    var isPristine by remember { mutableStateOf(true) }
    var showKeypad by remember { mutableStateOf(true) }

    val m2PerCartonVal = (colisageM2Str.toDoubleOrNull() ?: product?.m2Carton ?: 1.44).coerceAtLeast(0.01)
    val pcsPerCartonVal = (pcsPerCartonStr.toIntOrNull() ?: product?.pcs ?: 4).coerceAtLeast(1)
    val prixVal = (pricePerM2Str.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)

    val result = remember(
        mode, surfaceStr, lengthStr, widthStr, cartonsStr, piecesStr,
        marginPercent, m2PerCartonVal, pcsPerCartonVal, prixVal
    ) {
        when (mode) {
            CalcInputMode.SURFACE -> TileCalculatorMath.calculateFromSurface(
                surfaceM2 = surfaceStr.toDoubleOrNull() ?: 0.0,
                marginPercent = marginPercent,
                m2PerCarton = m2PerCartonVal,
                pcsPerCarton = pcsPerCartonVal,
                prixPerM2 = prixVal
            )
            CalcInputMode.DIMENSIONS -> TileCalculatorMath.calculateFromDimensions(
                lengthMeters = lengthStr.toDoubleOrNull() ?: 0.0,
                widthMeters = widthStr.toDoubleOrNull() ?: 0.0,
                marginPercent = marginPercent,
                m2PerCarton = m2PerCartonVal,
                pcsPerCarton = pcsPerCartonVal,
                prixPerM2 = prixVal
            )
            CalcInputMode.CARTONS_PIECES -> TileCalculatorMath.calculateFromCartonsAndPieces(
                cartons = cartonsStr.toIntOrNull() ?: 0,
                loosePieces = piecesStr.toIntOrNull() ?: 0,
                m2PerCarton = m2PerCartonVal,
                pcsPerCarton = pcsPerCartonVal,
                prixPerM2 = prixVal
            )
        }
    }

    fun selectNumericField(target: CalcFieldTarget) {
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
        activeField = target
        isPristine = true
        showKeypad = true
    }

    fun currentFieldValue(): String = when (activeField) {
        CalcFieldTarget.SURFACE -> surfaceStr
        CalcFieldTarget.LENGTH -> lengthStr
        CalcFieldTarget.WIDTH -> widthStr
        CalcFieldTarget.CARTONS -> cartonsStr
        CalcFieldTarget.PIECES -> piecesStr
        CalcFieldTarget.COLISAGE_M2 -> colisageM2Str
        CalcFieldTarget.PCS_PER_CARTON -> pcsPerCartonStr
        CalcFieldTarget.PRICE_PER_M2 -> pricePerM2Str
    }

    fun setFieldValue(newVal: String) {
        when (activeField) {
            CalcFieldTarget.SURFACE -> surfaceStr = newVal
            CalcFieldTarget.LENGTH -> lengthStr = newVal
            CalcFieldTarget.WIDTH -> widthStr = newVal
            CalcFieldTarget.CARTONS -> cartonsStr = newVal
            CalcFieldTarget.PIECES -> piecesStr = newVal
            CalcFieldTarget.COLISAGE_M2 -> colisageM2Str = newVal
            CalcFieldTarget.PCS_PER_CARTON -> pcsPerCartonStr = newVal
            CalcFieldTarget.PRICE_PER_M2 -> pricePerM2Str = newVal
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Slate950,
        contentColor = Slate100,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp)
                .align(Alignment.CenterHorizontally)
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp)
                .testTag("smart_tile_calculator_sheet"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (product != null) {
                        TileSwatchImage(
                            imageUrl = product.image,
                            colorHex = product.color,
                            contentDescription = product.name,
                            modifier = Modifier.size(46.dp),
                            cornerRadius = 12.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                    } else {
                        Surface(
                            modifier = Modifier.size(44.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = Cyan950,
                            border = BorderStroke(1.dp, Cyan500.copy(alpha = 0.5f))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = "Calculateur",
                                    tint = Cyan400
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                    }
                    Column {
                        Text(
                            text = product?.name ?: editingCartItem?.name ?: "Calculateur Intelligent m² / Ctn",
                            style = MaterialTheme.typography.titleMedium,
                            color = Slate100,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val subtitle = if (product != null) {
                            "${product.usine} • ${product.dimension} • ${formatM2(product.m2Carton)} m²/ctn (${product.pcs} pcs)"
                        } else if (editingCartItem != null) {
                            "${editingCartItem.usine} • ${editingCartItem.dimension} • ${formatM2(editingCartItem.m2Carton)} m²/ctn"
                        } else {
                            "Conversion instantanée Surface ↔ Cartons & Pièces"
                        }
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = Cyan300,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (product != null) {
                    val inStock = product.stock > 0
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (inStock) Emerald950 else Rose950,
                        border = BorderStroke(
                            1.dp,
                            if (inStock) Emerald500.copy(alpha = 0.45f) else Rose400.copy(alpha = 0.45f)
                        )
                    ) {
                        Text(
                            text = if (inStock) "Stock: ${product.stock} ctn" else "Sur Cmd",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (inStock) Emerald400 else Rose400,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("calc_close_btn")
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Slate400)
                }
            }

            // Mode Selector Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CalcModeChip(
                    selected = mode == CalcInputMode.SURFACE,
                    label = "Surface (m²)",
                    icon = Icons.Default.SquareFoot,
                    onClick = {
                        mode = CalcInputMode.SURFACE
                        selectNumericField(CalcFieldTarget.SURFACE)
                    },
                    modifier = Modifier.weight(1f),
                    testTag = "calc_tab_surface"
                )
                CalcModeChip(
                    selected = mode == CalcInputMode.DIMENSIONS,
                    label = "Pièce (L×l)",
                    icon = Icons.Default.Straighten,
                    onClick = {
                        mode = CalcInputMode.DIMENSIONS
                        selectNumericField(CalcFieldTarget.LENGTH)
                    },
                    modifier = Modifier.weight(1f),
                    testTag = "calc_tab_dimensions"
                )
                CalcModeChip(
                    selected = mode == CalcInputMode.CARTONS_PIECES,
                    label = "Cartons",
                    icon = Icons.Default.GridOn,
                    onClick = {
                        mode = CalcInputMode.CARTONS_PIECES
                        if (cartonsStr == "0") cartonsStr = result.cartons.coerceAtLeast(1).toString()
                        selectNumericField(CalcFieldTarget.CARTONS)
                    },
                    modifier = Modifier.weight(1f),
                    testTag = "calc_tab_cartons"
                )
            }

            // Standalone Colisage Presets (if not bound to a catalog tile)
            if (!isTileBound) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Colisage m² / carton (Formules standards)",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate400
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TileCalculatorMath.COLISAGE_PRESETS.forEach { preset ->
                            val isSel = kotlin.math.abs(m2PerCartonVal - preset) < 0.005
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    focusManager.clearFocus(force = true)
                                    keyboardController?.hide()
                                    colisageM2Str = formatM2(preset)
                                },
                                label = {
                                    Text(
                                        text = "${formatM2(preset)} m²",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Cyan950,
                                    selectedLabelColor = Cyan300,
                                    containerColor = Slate900,
                                    labelColor = Slate400
                                )
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NumericDisplayField(
                            label = "m² / Carton",
                            value = colisageM2Str,
                            isActive = showKeypad && activeField == CalcFieldTarget.COLISAGE_M2,
                            onSelect = { selectNumericField(CalcFieldTarget.COLISAGE_M2) },
                            suffix = "m²",
                            accentColor = Cyan400,
                            modifier = Modifier.weight(1f),
                            testTag = "calc_colisage_field"
                        )
                        NumericDisplayField(
                            label = "Pcs / Carton",
                            value = pcsPerCartonStr,
                            isActive = showKeypad && activeField == CalcFieldTarget.PCS_PER_CARTON,
                            onSelect = { selectNumericField(CalcFieldTarget.PCS_PER_CARTON) },
                            suffix = "pcs",
                            accentColor = Cyan400,
                            modifier = Modifier.weight(1f),
                            testTag = "calc_pcs_per_carton_field"
                        )
                    }
                }
            }

            // Primary Calculation Inputs
            when (mode) {
                CalcInputMode.SURFACE -> {
                    NumericDisplayField(
                        label = "Surface souhaitée à couvrir",
                        value = surfaceStr,
                        isActive = showKeypad && activeField == CalcFieldTarget.SURFACE,
                        onSelect = { selectNumericField(CalcFieldTarget.SURFACE) },
                        suffix = "m²",
                        accentColor = Amber400,
                        testTag = "calc_surface_field"
                    )
                    MarginChipsRow(
                        selectedMargin = marginPercent,
                        onSelectMargin = {
                            focusManager.clearFocus(force = true)
                            keyboardController?.hide()
                            marginPercent = it
                        }
                    )
                }

                CalcInputMode.DIMENSIONS -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NumericDisplayField(
                            label = "Longueur (L)",
                            value = lengthStr,
                            isActive = showKeypad && activeField == CalcFieldTarget.LENGTH,
                            onSelect = { selectNumericField(CalcFieldTarget.LENGTH) },
                            suffix = "m",
                            accentColor = Amber400,
                            modifier = Modifier.weight(1f),
                            testTag = "calc_length_field"
                        )
                        NumericDisplayField(
                            label = "Largeur (l)",
                            value = widthStr,
                            isActive = showKeypad && activeField == CalcFieldTarget.WIDTH,
                            onSelect = { selectNumericField(CalcFieldTarget.WIDTH) },
                            suffix = "m",
                            accentColor = Amber400,
                            modifier = Modifier.weight(1f),
                            testTag = "calc_width_field"
                        )
                    }
                    MarginChipsRow(
                        selectedMargin = marginPercent,
                        onSelectMargin = {
                            focusManager.clearFocus(force = true)
                            keyboardController?.hide()
                            marginPercent = it
                        }
                    )
                }

                CalcInputMode.CARTONS_PIECES -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            NumericDisplayField(
                                label = "Cartons complets",
                                value = cartonsStr,
                                isActive = showKeypad && activeField == CalcFieldTarget.CARTONS,
                                onSelect = { selectNumericField(CalcFieldTarget.CARTONS) },
                                suffix = "ctn",
                                accentColor = Amber400,
                                testTag = "calc_cartons_field"
                            )
                            StepperRow(
                                onMinus = {
                                    val c = (cartonsStr.toIntOrNull() ?: 0).minus(1).coerceAtLeast(0)
                                    cartonsStr = c.toString()
                                },
                                onPlus = {
                                    val c = (cartonsStr.toIntOrNull() ?: 0) + 1
                                    cartonsStr = c.toString()
                                }
                            )
                        }
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            NumericDisplayField(
                                label = "Pièces en plus",
                                value = piecesStr,
                                isActive = showKeypad && activeField == CalcFieldTarget.PIECES,
                                onSelect = { selectNumericField(CalcFieldTarget.PIECES) },
                                suffix = "pcs",
                                accentColor = Cyan400,
                                testTag = "calc_pieces_field"
                            )
                            StepperRow(
                                onMinus = {
                                    val p = (piecesStr.toIntOrNull() ?: 0).minus(1).coerceAtLeast(0)
                                    piecesStr = p.toString()
                                },
                                onPlus = {
                                    val p = (piecesStr.toIntOrNull() ?: 0) + 1
                                    piecesStr = p.toString()
                                }
                            )
                        }
                    }
                }
            }

            // Live Breakdown Hero Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = Slate900,
                border = BorderStroke(1.5.dp, Cyan500.copy(alpha = 0.55f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(Cyan950.copy(alpha = 0.65f), Slate900)
                            )
                        )
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = buildString {
                                        append("${result.cartons} Carton")
                                        if (result.cartons > 1) append("s")
                                        if (result.loosePieces > 0) {
                                            append(" + ${result.loosePieces} Pcs")
                                        }
                                    },
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Amber400,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "${formatM2(result.deliveredM2)} m² livrés (${formatM2(result.m2PerCarton)} m²/ctn)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Cyan300,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Total Ligne",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Slate400
                                )
                                Text(
                                    text = formatDa(result.totalDa),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Emerald400,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }

                        if (mode != CalcInputMode.CARTONS_PIECES && result.surplusM2 > 0.005) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (marginPercent > 0) {
                                        "Besoin: ${formatM2(result.requestedM2)} m² + $marginPercent% = ${formatM2(result.targetM2WithMargin)} m²"
                                    } else {
                                        "Besoin: ${formatM2(result.requestedM2)} m²"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Slate400
                                )
                                Text(
                                    text = "Surplus +${formatM2(result.surplusM2)} m²",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Emerald300,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Price per m2 & Optional Bain/Calibre Note
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NumericDisplayField(
                    label = "Prix / m²",
                    value = pricePerM2Str,
                    isActive = showKeypad && activeField == CalcFieldTarget.PRICE_PER_M2,
                    onSelect = { selectNumericField(CalcFieldTarget.PRICE_PER_M2) },
                    suffix = "DA",
                    accentColor = Emerald400,
                    modifier = Modifier.weight(1f),
                    testTag = "calc_price_field"
                )
                if (isTileBound) {
                    OutlinedTextField(
                        value = bainNote,
                        onValueChange = { bainNote = it },
                        label = { Text("Bain / Calibre", maxLines = 1) },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1.2f)
                            .dismissKeypadOnTextFocus { showKeypad = false }
                            .testTag("calc_bain_input"),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan400,
                            unfocusedBorderColor = Slate700,
                            focusedTextColor = Slate100,
                            unfocusedTextColor = Slate100,
                            focusedContainerColor = Slate950,
                            unfocusedContainerColor = Slate950
                        )
                    )
                }
            }

            // Embedded Non-IME Keypad (auto-hides if text field gains focus)
            AnimatedVisibility(
                visible = showKeypad,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                val chips = when (activeField) {
                    CalcFieldTarget.SURFACE -> listOf("+5" to 5.0, "+10" to 10.0, "+25" to 25.0, "+50" to 50.0)
                    CalcFieldTarget.CARTONS -> listOf("+1" to 1.0, "+5" to 5.0, "+10" to 10.0, "+20" to 20.0)
                    CalcFieldTarget.PRICE_PER_M2 -> listOf("+50" to 50.0, "+100" to 100.0, "-50" to -50.0)
                    else -> emptyList()
                }
                NonImeNumericKeypad(
                    onKeyPress = { key ->
                        val (nextVal, nextPristine) = applyKeypadInput(
                            current = currentFieldValue(),
                            key = key,
                            allowDecimal = activeField.allowDecimal,
                            isPristine = isPristine
                        )
                        setFieldValue(nextVal)
                        isPristine = nextPristine
                    },
                    allowDecimal = activeField.allowDecimal,
                    quickChips = chips,
                    onQuickDelta = { delta ->
                        val next = applyKeypadQuickDelta(
                            current = currentFieldValue(),
                            delta = delta,
                            allowDecimal = activeField.allowDecimal
                        )
                        setFieldValue(next)
                        isPristine = false
                    },
                    onValidate = {
                        if (isTileBound && product != null && result.deliveredM2 > 0.0) {
                            onConfirmProductCart(
                                product,
                                result.cartons,
                                result.loosePieces,
                                result.deliveredM2,
                                prixVal,
                                bainNote.trim(),
                                calibreNote.trim(),
                                editingCartItem?.id
                            )
                        } else if (!isTileBound && result.deliveredM2 > 0.0) {
                            onConfirmStandaloneFreeLine(
                                FreeLineItem(
                                    id = "calc_${UUID.randomUUID().toString().take(8)}",
                                    designation = "Carrelage ${formatM2(m2PerCartonVal)}m²/ctn (${result.cartons} ctn)",
                                    quantite = result.deliveredM2,
                                    unite = "m²",
                                    prixUnitaire = prixVal,
                                    sousTotal = result.totalDa
                                )
                            )
                        }
                    },
                    validateLabel = when {
                        editingCartItem != null -> "Mettre à jour"
                        isTileBound -> "Ajouter (${result.cartons} ctn)"
                        else -> "Ajouter au Panier"
                    },
                    accentColor = Amber500
                )
            }

            // Secondary Action Bar (shown always, especially useful when text field hid keypad)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!isTileBound) {
                    OutlinedButton(
                        onClick = {
                            surfaceStr = "0"
                            lengthStr = "0"
                            widthStr = "0"
                            cartonsStr = "0"
                            piecesStr = "0"
                            marginPercent = 0
                            selectNumericField(CalcFieldTarget.SURFACE)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("calc_reset_btn"),
                        border = BorderStroke(1.dp, Slate700),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = Slate400, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Réinitialiser", color = Slate100)
                    }
                }
                Button(
                    onClick = {
                        if (isTileBound && product != null && result.deliveredM2 > 0.0) {
                            onConfirmProductCart(
                                product,
                                result.cartons,
                                result.loosePieces,
                                result.deliveredM2,
                                prixVal,
                                bainNote.trim(),
                                calibreNote.trim(),
                                editingCartItem?.id
                            )
                        } else if (!isTileBound && result.deliveredM2 > 0.0) {
                            onConfirmStandaloneFreeLine(
                                FreeLineItem(
                                    id = "calc_${UUID.randomUUID().toString().take(8)}",
                                    designation = "Carrelage ${formatM2(m2PerCartonVal)}m²/ctn (${result.cartons} ctn)",
                                    quantite = result.deliveredM2,
                                    unite = "m²",
                                    prixUnitaire = prixVal,
                                    sousTotal = result.totalDa
                                )
                            )
                        }
                    },
                    enabled = result.deliveredM2 > 0.0,
                    modifier = Modifier
                        .weight(1.6f)
                        .height(48.dp)
                        .testTag("calc_confirm_action_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Emerald500,
                        contentColor = Slate950
                    )
                ) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (editingCartItem != null) {
                            "Valider Modification"
                        } else {
                            "Ajouter • ${formatDa(result.totalDa)}"
                        },
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun CalcModeChip(
    selected: Boolean,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Surface(
        modifier = modifier
            .height(44.dp)
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Amber500 else Slate900,
        border = BorderStroke(1.dp, if (selected) Amber400 else Slate700)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) Slate950 else Slate400,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = if (selected) Slate950 else Slate100,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MarginChipsRow(
    selectedMargin: Int,
    onSelectMargin: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = "Coupe :",
            style = MaterialTheme.typography.labelSmall,
            color = Slate400
        )
        TileCalculatorMath.MARGIN_PRESETS.forEach { margin ->
            val isSel = selectedMargin == margin
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelectMargin(margin) }
                    .testTag("calc_margin_$margin"),
                shape = RoundedCornerShape(10.dp),
                color = if (isSel) Amber950 else Slate900,
                border = BorderStroke(1.dp, if (isSel) Amber500 else Slate700)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = if (margin == 0) "Exact 0%" else "+$margin%",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isSel) Amber300 else Slate400,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun StepperRow(
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Surface(
            modifier = Modifier
                .weight(1f)
                .height(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onMinus),
            shape = RoundedCornerShape(10.dp),
            color = Slate850,
            border = BorderStroke(1.dp, Slate700)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Remove, contentDescription = "Moins", tint = Slate100, modifier = Modifier.size(16.dp))
            }
        }
        Surface(
            modifier = Modifier
                .weight(1f)
                .height(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onPlus),
            shape = RoundedCornerShape(10.dp),
            color = Slate850,
            border = BorderStroke(1.dp, Slate700)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Add, contentDescription = "Plus", tint = Cyan400, modifier = Modifier.size(16.dp))
            }
        }
    }
}
