package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.FreeLineItem
import com.example.data.model.Invoice
import com.example.data.model.InvoiceClient
import com.example.data.model.PosSeeds
import com.example.data.model.TileProduct
import com.example.data.model.formatDa
import com.example.data.model.formatM2
import com.example.ui.components.NonImeNumericKeypad
import com.example.ui.components.NumericDisplayField
import com.example.ui.components.TileSwatchImage
import com.example.ui.components.applyKeypadInput
import com.example.ui.components.applyKeypadQuickDelta
import com.example.ui.components.dismissKeypadOnTextFocus
import com.example.ui.theme.Amber300
import com.example.ui.theme.Amber400
import com.example.ui.theme.Amber500
import com.example.ui.theme.Amber950
import com.example.ui.theme.Cyan300
import com.example.ui.theme.Cyan400
import com.example.ui.theme.Cyan500
import com.example.ui.theme.Cyan950
import com.example.ui.theme.Emerald300
import com.example.ui.theme.Emerald400
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Emerald950
import com.example.ui.theme.Rose400
import com.example.ui.theme.Rose950
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate850
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosScreen(
    products: List<TileProduct>,
    cart: List<CartItem>,
    freeLines: List<FreeLineItem>,
    customers: List<Customer>,
    editingInvoice: Invoice?,
    onQuickAddOneCarton: (TileProduct) -> Unit,
    onOpenCalculatorForProduct: (TileProduct) -> Unit,
    onEditCartItem: (CartItem) -> Unit,
    onAdjustCartItemCarton: (String, Int) -> Unit,
    onRemoveCartItem: (String) -> Unit,
    onAddFreeLine: (FreeLineItem) -> Unit,
    onRemoveFreeLine: (String) -> Unit,
    onClearCart: () -> Unit,
    onFinalizeSale: (InvoiceClient, Double, Double, String, String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedUsine by remember { mutableStateOf("Toutes") }
    var selectedDimension by remember { mutableStateOf("Toutes") }
    var selectedChoix by remember { mutableStateOf("Tous") }
    var onlyInStock by remember { mutableStateOf(false) }

    var showCartSheet by remember { mutableStateOf(false) }
    var showDiversDialog by remember { mutableStateOf(false) }
    var showCheckoutDialog by remember { mutableStateOf(false) }
    var previewProduct by remember { mutableStateOf<TileProduct?>(null) }

    val usines = remember(products) {
        listOf("Toutes") + products.map { it.usine }.distinct().sorted()
    }
    val dimensions = remember(products) {
        listOf("Toutes") + products.map { it.dimension }.distinct().sorted()
    }

    val filteredProducts = remember(
        products, searchQuery, selectedUsine, selectedDimension, selectedChoix, onlyInStock
    ) {
        val q = searchQuery.trim().lowercase()
        products.filter { p ->
            (q.isEmpty() || p.name.lowercase().contains(q) || p.usine.lowercase().contains(q) || p.dimension.lowercase().contains(q)) &&
                (selectedUsine == "Toutes" || p.usine == selectedUsine) &&
                (selectedDimension == "Toutes" || p.dimension == selectedDimension) &&
                (selectedChoix == "Tous" || p.choix == selectedChoix) &&
                (!onlyInStock || p.stock > 0)
        }
    }

    val totalBrut = remember(cart, freeLines) {
        cart.sumOf { it.sousTotal } + freeLines.sumOf { it.sousTotal }
    }
    val totalLinesCount = cart.size + freeLines.size

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWide = maxWidth >= 840.dp

        Row(modifier = Modifier.fillMaxSize()) {
            // Left / Main Catalog Pane
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Search + Filter Strip
                    Surface(
                        color = Slate900,
                        border = BorderStroke(1.dp, Slate800)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (editingInvoice != null) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Amber950,
                                    border = BorderStroke(1.dp, Amber500.copy(alpha = 0.6f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Mode édition : Facture #${editingInvoice.reference}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = Amber300
                                        )
                                        TextButton(onClick = onClearCart) {
                                            Text("Annuler", color = Rose400)
                                        }
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder = { Text("Rechercher modèle, usine, format...", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Cyan400) },
                                    trailingIcon = {
                                        if (searchQuery.isNotEmpty()) {
                                            IconButton(onClick = { searchQuery = "" }) {
                                                Icon(Icons.Default.Clear, contentDescription = "Effacer", tint = Slate400)
                                            }
                                        }
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Cyan400,
                                        unfocusedBorderColor = Slate700,
                                        focusedTextColor = Slate100,
                                        unfocusedTextColor = Slate100,
                                        focusedContainerColor = Slate950,
                                        unfocusedContainerColor = Slate950
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("pos_search_input")
                                )

                                Button(
                                    onClick = { showDiversDialog = true },
                                    modifier = Modifier
                                        .height(54.dp)
                                        .testTag("pos_divers_btn"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Amber950,
                                        contentColor = Amber300
                                    ),
                                    border = BorderStroke(1.dp, Amber500.copy(alpha = 0.5f)),
                                    contentPadding = PaddingValues(horizontal = 12.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Divers", fontWeight = FontWeight.Bold)
                                }
                            }

                            // Filters Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                FilterChip(
                                    selected = onlyInStock,
                                    onClick = { onlyInStock = !onlyInStock },
                                    label = { Text("En stock (${products.count { it.stock > 0 }})") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Emerald950,
                                        selectedLabelColor = Emerald300,
                                        containerColor = Slate950,
                                        labelColor = Slate400
                                    )
                                )
                                listOf("Tous", "1er Choix", "2ème Choix").forEach { choix ->
                                    FilterChip(
                                        selected = selectedChoix == choix,
                                        onClick = { selectedChoix = choix },
                                        label = { Text(choix) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = Cyan950,
                                            selectedLabelColor = Cyan300,
                                            containerColor = Slate950,
                                            labelColor = Slate400
                                        )
                                    )
                                }
                                usines.forEach { u ->
                                    if (u != "Toutes") {
                                        FilterChip(
                                            selected = selectedUsine == u,
                                            onClick = { selectedUsine = if (selectedUsine == u) "Toutes" else u },
                                            label = { Text(u) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Amber950,
                                                selectedLabelColor = Amber300,
                                                containerColor = Slate950,
                                                labelColor = Slate400
                                            )
                                        )
                                    }
                                }
                                dimensions.forEach { d ->
                                    if (d != "Toutes") {
                                        FilterChip(
                                            selected = selectedDimension == d,
                                            onClick = { selectedDimension = if (selectedDimension == d) "Toutes" else d },
                                            label = { Text(d) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Slate800,
                                                selectedLabelColor = Slate100,
                                                containerColor = Slate950,
                                                labelColor = Slate400
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (filteredProducts.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Inventory2, contentDescription = null, tint = Slate400, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Aucun modèle trouvé", style = MaterialTheme.typography.titleMedium, color = Slate100)
                                Text("Essayez d'ajuster les filtres d'usine ou de format.", style = MaterialTheme.typography.bodySmall, color = Slate400)
                            }
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 172.dp),
                            contentPadding = PaddingValues(
                                start = 12.dp,
                                end = 12.dp,
                                top = 12.dp,
                                bottom = if (isWide) 16.dp else 96.dp
                            ),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredProducts, key = { it.id }) { product ->
                                ProductTileCard(
                                    product = product,
                                    onQuickAdd = { onQuickAddOneCarton(product) },
                                    onOpenCalculator = { onOpenCalculatorForProduct(product) },
                                    onPreviewImage = { previewProduct = product }
                                )
                            }
                        }
                    }
                }

                // Floating Cart Bar on Compact/Medium Screens
                if (!isWide) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { showCartSheet = true }
                            .testTag("pos_floating_cart_bar"),
                        shape = RoundedCornerShape(18.dp),
                        color = Slate900,
                        border = BorderStroke(1.5.dp, if (totalLinesCount > 0) Amber500 else Slate700),
                        tonalElevation = 8.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BadgedBox(
                                    badge = {
                                        if (totalLinesCount > 0) {
                                            Badge(containerColor = Amber500, contentColor = Slate950) {
                                                Text(totalLinesCount.toString())
                                            }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.ShoppingCart, contentDescription = "Panier", tint = Amber400)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (totalLinesCount == 0) "Panier vide" else "${cart.sumOf { it.cartons }} Ctn • ${formatM2(cart.sumOf { it.m2Total })} m²",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = Slate100
                                    )
                                    Text(
                                        text = formatDa(totalBrut),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Emerald400,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    if (totalLinesCount > 0) showCheckoutDialog = true else showCartSheet = true
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (totalLinesCount > 0) Emerald500 else Cyan500,
                                    contentColor = Slate950
                                )
                            ) {
                                Text(
                                    text = if (totalLinesCount > 0) "Encaisser" else "Voir Panier",
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }

            // Persistent Side Cart Pane on Tablets/Expanded Screens
            if (isWide) {
                Surface(
                    modifier = Modifier
                        .width(360.dp)
                        .fillMaxHeight(),
                    color = Slate900,
                    border = BorderStroke(1.dp, Slate800)
                ) {
                    CartPanelContent(
                        cart = cart,
                        freeLines = freeLines,
                        totalBrut = totalBrut,
                        editingInvoice = editingInvoice,
                        onEditCartItem = onEditCartItem,
                        onAdjustCartItemCarton = onAdjustCartItemCarton,
                        onRemoveCartItem = onRemoveCartItem,
                        onRemoveFreeLine = onRemoveFreeLine,
                        onClearCart = onClearCart,
                        onOpenDivers = { showDiversDialog = true },
                        onOpenCheckout = { showCheckoutDialog = true }
                    )
                }
            }
        }
    }

    if (showCartSheet) {
        BackHandler { showCartSheet = false }
        ModalBottomSheet(
            onDismissRequest = { showCartSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Slate900,
            contentColor = Slate100
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(560.dp)
                    .navigationBarsPadding()
            ) {
                CartPanelContent(
                    cart = cart,
                    freeLines = freeLines,
                    totalBrut = totalBrut,
                    editingInvoice = editingInvoice,
                    onEditCartItem = {
                        showCartSheet = false
                        onEditCartItem(it)
                    },
                    onAdjustCartItemCarton = onAdjustCartItemCarton,
                    onRemoveCartItem = onRemoveCartItem,
                    onRemoveFreeLine = onRemoveFreeLine,
                    onClearCart = onClearCart,
                    onOpenDivers = { showDiversDialog = true },
                    onOpenCheckout = {
                        showCartSheet = false
                        showCheckoutDialog = true
                    }
                )
            }
        }
    }

    if (showDiversDialog) {
        DiversLineDialog(
            onDismiss = { showDiversDialog = false },
            onAddLine = {
                onAddFreeLine(it)
                showDiversDialog = false
            }
        )
    }

    if (showCheckoutDialog) {
        CheckoutModalDialog(
            totalBrut = totalBrut,
            customers = customers,
            editingInvoice = editingInvoice,
            onDismiss = { showCheckoutDialog = false },
            onConfirm = { client, remise, paye, mode, notes ->
                showCheckoutDialog = false
                onFinalizeSale(client, remise, paye, mode, notes)
            }
        )
    }

    previewProduct?.let { prod ->
        Dialog(onDismissRequest = { previewProduct = null }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Slate900,
                border = BorderStroke(1.dp, Slate700)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TileSwatchImage(
                        imageUrl = prod.image,
                        colorHex = prod.color,
                        contentDescription = prod.name,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp),
                        cornerRadius = 14.dp
                    )
                    Text(prod.name, style = MaterialTheme.typography.titleLarge, color = Slate100, fontWeight = FontWeight.Black)
                    Text("${prod.usine} • ${prod.dimension} • ${prod.choix} (${prod.finition})", style = MaterialTheme.typography.bodySmall, color = Cyan400)
                    Text("${formatM2(prod.m2Carton)} m²/ctn (${prod.pcs} pcs) • ${formatDa(prod.prix)}/m²", style = MaterialTheme.typography.titleSmall, color = Amber400)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { previewProduct = null }, modifier = Modifier.weight(1f)) {
                            Text("Fermer", color = Slate100)
                        }
                        Button(
                            onClick = {
                                previewProduct = null
                                onOpenCalculatorForProduct(prod)
                            },
                            modifier = Modifier.weight(1.3f),
                            colors = ButtonDefaults.buttonColors(containerColor = Cyan500, contentColor = Slate950)
                        ) {
                            Text("Calculer m²", fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductTileCard(
    product: TileProduct,
    onQuickAdd: () -> Unit,
    onOpenCalculator: () -> Unit,
    onPreviewImage: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}"),
        shape = RoundedCornerShape(16.dp),
        color = Slate900,
        border = BorderStroke(1.dp, Slate800)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box {
                TileSwatchImage(
                    imageUrl = product.image,
                    colorHex = product.color,
                    contentDescription = product.name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(106.dp)
                        .clickable(onClick = onPreviewImage),
                    cornerRadius = 12.dp
                )
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp),
                    shape = RoundedCornerShape(8.dp),
                    color = Slate950.copy(alpha = 0.85f)
                ) {
                    Text(
                        text = product.dimension,
                        style = MaterialTheme.typography.labelSmall,
                        color = Cyan300,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp),
                    shape = RoundedCornerShape(8.dp),
                    color = if (product.stock > 0) Emerald950.copy(alpha = 0.92f) else Rose950.copy(alpha = 0.92f)
                ) {
                    Text(
                        text = if (product.stock > 0) "${product.stock} ctn" else "Rupture",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (product.stock > 0) Emerald300 else Rose400,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = product.usine,
                    style = MaterialTheme.typography.labelSmall,
                    color = Amber400,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleSmall,
                    color = Slate100,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    minLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = formatDa(product.prix),
                        style = MaterialTheme.typography.titleMedium,
                        color = Emerald400,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "${formatM2(product.m2Carton)} m²/ctn",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate400
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Slate850
                ) {
                    Text(
                        text = product.choix,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (product.choix.contains("2")) Amber300 else Slate400,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenCalculator,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(44.dp)
                        .testTag("btn_calc_${product.id}"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Cyan500.copy(alpha = 0.6f)),
                    contentPadding = PaddingValues(horizontal = 6.dp)
                ) {
                    Icon(Icons.Default.Calculate, contentDescription = "Calculer m²", tint = Cyan400, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("m²/Ctn", color = Cyan300, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }
                Button(
                    onClick = onQuickAdd,
                    modifier = Modifier
                        .weight(0.9f)
                        .height(44.dp)
                        .testTag("btn_quick_add_${product.id}"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber500, contentColor = Slate950),
                    contentPadding = PaddingValues(horizontal = 6.dp)
                ) {
                    Text("+1 Ctn", fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun CartPanelContent(
    cart: List<CartItem>,
    freeLines: List<FreeLineItem>,
    totalBrut: Double,
    editingInvoice: Invoice?,
    onEditCartItem: (CartItem) -> Unit,
    onAdjustCartItemCarton: (String, Int) -> Unit,
    onRemoveCartItem: (String) -> Unit,
    onRemoveFreeLine: (String) -> Unit,
    onClearCart: () -> Unit,
    onOpenDivers: () -> Unit,
    onOpenCheckout: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (editingInvoice != null) "Édition #${editingInvoice.reference}" else "Panier & Commande",
                    style = MaterialTheme.typography.titleLarge,
                    color = Slate100,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "${cart.sumOf { it.cartons }} cartons • ${formatM2(cart.sumOf { it.m2Total })} m²",
                    style = MaterialTheme.typography.bodySmall,
                    color = Cyan400
                )
            }
            if (cart.isNotEmpty() || freeLines.isNotEmpty()) {
                IconButton(onClick = onClearCart) {
                    Icon(Icons.Default.Delete, contentDescription = "Vider panier", tint = Rose400)
                }
            }
        }

        HorizontalDivider(color = Slate800)

        if (cart.isEmpty() && freeLines.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Slate400, modifier = Modifier.size(44.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Votre panier est vide", color = Slate100, style = MaterialTheme.typography.titleSmall)
                    Text("Appuyez sur m²/Ctn ou +1 Ctn", color = Slate400, style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cart, key = { it.id }) { item ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Slate950,
                        border = BorderStroke(1.dp, Slate800)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.name, style = MaterialTheme.typography.titleSmall, color = Slate100, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${formatM2(item.m2Total)} m² • ${formatDa(item.prixUnitaire)}/m²" +
                                            if (item.bain.isNotBlank()) " • Bain ${item.bain}" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Cyan300
                                    )
                                }
                                IconButton(
                                    onClick = { onEditCartItem(item) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Modifier ligne", tint = Amber400, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = { onRemoveCartItem(item.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Retirer", tint = Rose400, modifier = Modifier.size(16.dp))
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Surface(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { onAdjustCartItemCarton(item.id, -1) },
                                        color = Slate850,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Remove, contentDescription = "Diminuer", tint = Slate100, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                    Text(
                                        text = "${item.cartons} ctn" + if (item.pieces > 0) "+${item.pieces}p" else "",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = Amber400
                                    )
                                    Surface(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { onAdjustCartItemCarton(item.id, 1) },
                                        color = Slate850,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Add, contentDescription = "Augmenter", tint = Cyan400, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                                Text(
                                    text = formatDa(item.sousTotal),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Emerald400,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }

                items(freeLines, key = { it.id }) { line ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Slate950,
                        border = BorderStroke(1.dp, Amber500.copy(alpha = 0.35f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(line.designation, style = MaterialTheme.typography.titleSmall, color = Slate100)
                                Text(
                                    text = "${formatM2(line.quantite)} ${line.unite} × ${formatDa(line.prixUnitaire)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Amber300
                                )
                            }
                            Text(
                                text = formatDa(line.sousTotal),
                                style = MaterialTheme.typography.titleSmall,
                                color = Emerald400,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { onRemoveFreeLine(line.id) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Retirer", tint = Rose400, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = Slate800)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Total Brut", style = MaterialTheme.typography.titleMedium, color = Slate400)
            Text(
                text = formatDa(totalBrut),
                style = MaterialTheme.typography.headlineSmall,
                color = Emerald400,
                fontWeight = FontWeight.Black
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onOpenDivers,
                modifier = Modifier.weight(1f).height(48.dp),
                border = BorderStroke(1.dp, Amber500.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("+ Divers", color = Amber300, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onOpenCheckout,
                enabled = cart.isNotEmpty() || freeLines.isNotEmpty(),
                modifier = Modifier
                    .weight(1.7f)
                    .height(48.dp)
                    .testTag("pos_checkout_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Slate950)
            ) {
                Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (editingInvoice != null) "Mettre à jour" else "Encaisser",
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

private enum class DiversNumTarget { QTY, PRICE }

@Composable
private fun DiversLineDialog(
    onDismiss: () -> Unit,
    onAddLine: (FreeLineItem) -> Unit
) {
    BackHandler { onDismiss() }
    var designation by remember { mutableStateOf("") }
    var unite by remember { mutableStateOf("sac") }
    var qtyStr by remember { mutableStateOf("1") }
    var priceStr by remember { mutableStateOf("750") }
    var activeTarget by remember { mutableStateOf(DiversNumTarget.QTY) }
    var showKeypad by remember { mutableStateOf(false) }
    var isPristine by remember { mutableStateOf(true) }

    val qtyVal = qtyStr.toDoubleOrNull() ?: 0.0
    val priceVal = priceStr.toDoubleOrNull() ?: 0.0

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().widthIn(max = 520.dp),
            shape = RoundedCornerShape(20.dp),
            color = Slate900,
            border = BorderStroke(1.dp, Slate700)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Ajouter Article Divers / Colle", style = MaterialTheme.typography.titleLarge, color = Amber400, fontWeight = FontWeight.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Slate400)
                    }
                }

                Text("Raccourcis rapides :", style = MaterialTheme.typography.labelSmall, color = Slate400)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PosSeeds.DIVERS_PRESETS.forEach { preset ->
                        FilterChip(
                            selected = designation == preset.designation,
                            onClick = {
                                designation = preset.designation
                                unite = preset.unite
                                priceStr = preset.prix.toInt().toString()
                                showKeypad = false
                            },
                            label = { Text("${preset.designation.take(18)} (${preset.prix.toInt()})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Amber950,
                                selectedLabelColor = Amber300,
                                containerColor = Slate950,
                                labelColor = Slate100
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = designation,
                    onValueChange = { designation = it },
                    label = { Text("Désignation") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dismissKeypadOnTextFocus { showKeypad = false },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan400,
                        unfocusedBorderColor = Slate700,
                        focusedTextColor = Slate100,
                        unfocusedTextColor = Slate100
                    )
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    NumericDisplayField(
                        label = "Quantité ($unite)",
                        value = qtyStr,
                        isActive = showKeypad && activeTarget == DiversNumTarget.QTY,
                        onSelect = {
                            activeTarget = DiversNumTarget.QTY
                            isPristine = true
                            showKeypad = true
                        },
                        modifier = Modifier.weight(1f),
                        testTag = "divers_qty_field"
                    )
                    NumericDisplayField(
                        label = "Prix Unitaire",
                        value = priceStr,
                        isActive = showKeypad && activeTarget == DiversNumTarget.PRICE,
                        onSelect = {
                            activeTarget = DiversNumTarget.PRICE
                            isPristine = true
                            showKeypad = true
                        },
                        suffix = "DA",
                        modifier = Modifier.weight(1.2f),
                        testTag = "divers_price_field"
                    )
                }

                AnimatedVisibility(visible = showKeypad, enter = expandVertically(), exit = shrinkVertically()) {
                    NonImeNumericKeypad(
                        onKeyPress = { key ->
                            val cur = if (activeTarget == DiversNumTarget.QTY) qtyStr else priceStr
                            val (next, nextPristine) = applyKeypadInput(cur, key, true, isPristine)
                            if (activeTarget == DiversNumTarget.QTY) qtyStr = next else priceStr = next
                            isPristine = nextPristine
                        },
                        allowDecimal = true,
                        onValidate = { showKeypad = false },
                        validateLabel = "OK"
                    )
                }

                Button(
                    onClick = {
                        if (designation.isNotBlank() && qtyVal > 0) {
                            onAddLine(
                                FreeLineItem(
                                    id = "div_${UUID.randomUUID().toString().take(8)}",
                                    designation = designation.trim(),
                                    quantite = qtyVal,
                                    unite = unite,
                                    prixUnitaire = priceVal,
                                    sousTotal = qtyVal * priceVal
                                )
                            )
                        }
                    },
                    enabled = designation.isNotBlank() && qtyVal > 0,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Slate950)
                ) {
                    Text("Ajouter (${formatDa(qtyVal * priceVal)})", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

private enum class CheckoutNumTarget { REMISE, PAYE }

@Composable
private fun CheckoutModalDialog(
    totalBrut: Double,
    customers: List<Customer>,
    editingInvoice: Invoice?,
    onDismiss: () -> Unit,
    onConfirm: (InvoiceClient, Double, Double, String, String) -> Unit
) {
    BackHandler { onDismiss() }
    var selectedCustomerId by remember { mutableStateOf(editingInvoice?.client?.id) }
    var clientName by remember { mutableStateOf(editingInvoice?.client?.nom ?: "Client Comptoir") }
    var clientPhone by remember { mutableStateOf(editingInvoice?.client?.tel ?: "") }
    var remiseStr by remember { mutableStateOf((editingInvoice?.remise ?: 0.0).toInt().toString()) }
    var modePaiement by remember { mutableStateOf(editingInvoice?.modePaiement ?: "Espèces") }
    val remiseVal = (remiseStr.toDoubleOrNull() ?: 0.0).coerceIn(0.0, totalBrut)
    val totalNet = (totalBrut - remiseVal).coerceAtLeast(0.0)
    var payeStr by remember {
        mutableStateOf((editingInvoice?.montantPaye ?: totalNet).toInt().toString())
    }
    var notes by remember { mutableStateOf(editingInvoice?.notes ?: "") }
    var activeTarget by remember { mutableStateOf(CheckoutNumTarget.PAYE) }
    var showKeypad by remember { mutableStateOf(false) }
    var isPristine by remember { mutableStateOf(true) }

    val payeVal = if (modePaiement == "Crédit") 0.0 else (payeStr.toDoubleOrNull() ?: 0.0).coerceIn(0.0, totalNet)
    val reste = (totalNet - payeVal).coerceAtLeast(0.0)

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().widthIn(max = 560.dp),
            shape = RoundedCornerShape(20.dp),
            color = Slate900,
            border = BorderStroke(1.dp, Slate700)
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Validation & Encaissement", style = MaterialTheme.typography.titleLarge, color = Emerald400, fontWeight = FontWeight.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Slate400)
                    }
                }

                Text("Client :", style = MaterialTheme.typography.labelSmall, color = Slate400)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedCustomerId == null,
                        onClick = {
                            selectedCustomerId = null
                            clientName = "Client Comptoir"
                            clientPhone = ""
                            showKeypad = false
                        },
                        label = { Text("Client Comptoir") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Cyan950,
                            selectedLabelColor = Cyan300
                        )
                    )
                    customers.forEach { c ->
                        FilterChip(
                            selected = selectedCustomerId == c.id,
                            onClick = {
                                selectedCustomerId = c.id
                                clientName = c.nom
                                clientPhone = c.tel
                                showKeypad = false
                            },
                            label = { Text(c.nom) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Amber950,
                                selectedLabelColor = Amber300
                            )
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = clientName,
                        onValueChange = { clientName = it },
                        label = { Text("Nom Client") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1.2f)
                            .dismissKeypadOnTextFocus { showKeypad = false },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan400,
                            unfocusedBorderColor = Slate700,
                            focusedTextColor = Slate100,
                            unfocusedTextColor = Slate100
                        )
                    )
                    OutlinedTextField(
                        value = clientPhone,
                        onValueChange = { clientPhone = it },
                        label = { Text("Tél") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .dismissKeypadOnTextFocus { showKeypad = false },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan400,
                            unfocusedBorderColor = Slate700,
                            focusedTextColor = Slate100,
                            unfocusedTextColor = Slate100
                        )
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Espèces", "Virement", "Chèque", "Crédit").forEach { mode ->
                        FilterChip(
                            selected = modePaiement == mode,
                            onClick = {
                                modePaiement = mode
                                if (mode == "Crédit") {
                                    payeStr = "0"
                                    showKeypad = false
                                } else if ((payeStr.toDoubleOrNull() ?: 0.0) == 0.0) {
                                    payeStr = totalNet.toInt().toString()
                                }
                            },
                            label = { Text(mode) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Emerald950,
                                selectedLabelColor = Emerald300
                            )
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    NumericDisplayField(
                        label = "Remise",
                        value = remiseStr,
                        isActive = showKeypad && activeTarget == CheckoutNumTarget.REMISE,
                        onSelect = {
                            activeTarget = CheckoutNumTarget.REMISE
                            isPristine = true
                            showKeypad = true
                        },
                        suffix = "DA",
                        accentColor = Amber400,
                        modifier = Modifier.weight(1f),
                        testTag = "checkout_remise_field"
                    )
                    NumericDisplayField(
                        label = "Montant Payé",
                        value = if (modePaiement == "Crédit") "0" else payeStr,
                        isActive = showKeypad && activeTarget == CheckoutNumTarget.PAYE,
                        onSelect = {
                            if (modePaiement == "Crédit") modePaiement = "Espèces"
                            activeTarget = CheckoutNumTarget.PAYE
                            isPristine = true
                            showKeypad = true
                        },
                        suffix = "DA",
                        accentColor = Emerald400,
                        modifier = Modifier.weight(1.2f),
                        testTag = "checkout_paye_field"
                    )
                }

                AnimatedVisibility(visible = showKeypad, enter = expandVertically(), exit = shrinkVertically()) {
                    NonImeNumericKeypad(
                        onKeyPress = { key ->
                            val cur = if (activeTarget == CheckoutNumTarget.REMISE) remiseStr else payeStr
                            val (next, nextPristine) = applyKeypadInput(cur, key, true, isPristine)
                            if (activeTarget == CheckoutNumTarget.REMISE) {
                                remiseStr = next
                                val nextNet = (totalBrut - (next.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0)
                                payeStr = nextNet.toInt().toString()
                            } else {
                                payeStr = next
                            }
                            isPristine = nextPristine
                        },
                        quickChips = listOf("+500" to 500.0, "+1000" to 1000.0, "+5000" to 5000.0),
                        onQuickDelta = { delta ->
                            val cur = if (activeTarget == CheckoutNumTarget.REMISE) remiseStr else payeStr
                            val next = applyKeypadQuickDelta(cur, delta, false)
                            if (activeTarget == CheckoutNumTarget.REMISE) {
                                remiseStr = next
                                val nextNet = (totalBrut - (next.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0)
                                payeStr = nextNet.toInt().toString()
                            } else {
                                payeStr = next
                            }
                            isPristine = false
                        },
                        allowDecimal = false,
                        onValidate = { showKeypad = false },
                        validateLabel = "OK"
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Slate950,
                    border = BorderStroke(1.dp, Slate800)
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Net :", color = Slate400, style = MaterialTheme.typography.bodyMedium)
                            Text(formatDa(totalNet), color = Slate100, fontWeight = FontWeight.Black)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Reste / Crédit :", color = Slate400, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = formatDa(reste),
                                color = if (reste > 0) Rose400 else Emerald400,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        onConfirm(
                            InvoiceClient(
                                id = selectedCustomerId,
                                nom = clientName.ifBlank { "Client Comptoir" },
                                tel = clientPhone.trim()
                            ),
                            remiseVal,
                            payeVal,
                            modePaiement,
                            notes.trim()
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("checkout_confirm_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Slate950)
                ) {
                    Text(
                        text = if (editingInvoice != null) "Enregistrer Modifications" else "Confirmer & Facturer",
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
