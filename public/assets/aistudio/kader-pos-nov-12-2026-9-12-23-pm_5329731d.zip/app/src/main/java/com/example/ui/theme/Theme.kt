package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val KaderDarkColorScheme = darkColorScheme(
    primary = Amber400,
    onPrimary = Slate950,
    primaryContainer = Amber950,
    onPrimaryContainer = Amber300,
    secondary = Cyan400,
    onSecondary = Slate950,
    secondaryContainer = Cyan950,
    onSecondaryContainer = Cyan300,
    tertiary = Emerald400,
    onTertiary = Slate950,
    tertiaryContainer = Emerald950,
    onTertiaryContainer = Emerald400,
    error = Rose400,
    onError = Slate950,
    errorContainer = Rose950,
    onErrorContainer = Rose400,
    background = Slate950,
    onBackground = Slate100,
    surface = Slate900,
    onSurface = Slate100,
    surfaceVariant = Slate800,
    onSurfaceVariant = Slate400,
    outline = Slate700,
    outlineVariant = Slate800,
    surfaceContainerLowest = Slate950,
    surfaceContainerLow = Slate900,
    surfaceContainer = Slate850,
    surfaceContainerHigh = Slate800,
    surfaceContainerHighest = Color(0xFF283548)
)

val KaderShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun KaderPosTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = KaderDarkColorScheme,
        typography = Typography,
        shapes = KaderShapes,
        content = content
    )
}
