package com.example.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.AppKvEntity
import com.example.data.local.PosJsonMapper
import com.example.data.local.PosJsonMapper.toEntity
import com.example.data.local.PosJsonMapper.toModel
import com.example.data.model.AppSettings
import com.example.data.model.CaisseMovement
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.DailyCaisseCount
import com.example.data.model.DepotNotification
import com.example.data.model.FreeLineItem
import com.example.data.model.Invoice
import com.example.data.model.PosSeeds
import com.example.data.model.StaffUser
import com.example.data.model.StoreInfo
import com.example.data.model.Supplier
import com.example.data.model.SupplierMovement
import com.example.data.model.TileProduct
import com.example.data.model.formatM2
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

data class SaleCommitResult(
    val invoice: Invoice,
    val caisseMovement: CaisseMovement?,
    val updatedCustomer: Customer?,
    val notification: DepotNotification,
    val updatedProductStocks: Map<String, Int>
)

class PosRepository(
    private val context: Context,
    private val db: AppDatabase
) {
    private val dao = db.posDao()

    companion object {
        private const val KV_CART = "active_cart"
        private const val KV_FREE_LINES = "free_lines"
        private const val KV_STORE_INFO = "store_info"
        private const val KV_SETTINGS = "app_settings"
        private const val KV_CURRENT_USER_ID = "current_user_id"
    }

    val productsFlow: Flow<List<TileProduct>> =
        dao.observeProducts().map { list -> list.map { it.toModel() } }

    val invoicesFlow: Flow<List<Invoice>> =
        dao.observeInvoices().map { list -> list.map { it.toModel() } }

    val customersFlow: Flow<List<Customer>> =
        dao.observeCustomers().map { list -> list.map { it.toModel() } }

    val suppliersFlow: Flow<List<Supplier>> =
        dao.observeSuppliers().map { list -> list.map { it.toModel() } }

    val supplierMovementsFlow: Flow<List<SupplierMovement>> =
        dao.observeSupplierMovements().map { list -> list.map { it.toModel() } }

    val caisseFlow: Flow<List<CaisseMovement>> =
        dao.observeCaisseMovements().map { list -> list.map { it.toModel() } }

    val dailyCaisseCountsFlow: Flow<List<DailyCaisseCount>> =
        dao.observeDailyCaisseCounts().map { list -> list.map { it.toModel() } }

    val usersFlow: Flow<List<StaffUser>> =
        dao.observeUsers().map { list -> list.map { it.toModel() } }

    val notificationsFlow: Flow<List<DepotNotification>> =
        dao.observeNotifications().map { list -> list.map { it.toModel() } }

    val cartFlow: Flow<List<CartItem>> =
        dao.observeKv(KV_CART).map { kv ->
            kv?.let { PosJsonMapper.jsonToCartItems(it.jsonValue) } ?: emptyList()
        }

    val freeLinesFlow: Flow<List<FreeLineItem>> =
        dao.observeKv(KV_FREE_LINES).map { kv ->
            kv?.let { PosJsonMapper.jsonToFreeLines(it.jsonValue) } ?: emptyList()
        }

    val storeInfoFlow: Flow<StoreInfo> =
        dao.observeKv(KV_STORE_INFO).map { kv ->
            kv?.let { PosJsonMapper.jsonToStoreInfo(it.jsonValue, PosSeeds.DEFAULT_STORE_INFO) }
                ?: PosSeeds.DEFAULT_STORE_INFO
        }

    val settingsFlow: Flow<AppSettings> =
        dao.observeKv(KV_SETTINGS).map { kv ->
            kv?.let { PosJsonMapper.jsonToSettings(it.jsonValue, PosSeeds.DEFAULT_SETTINGS) }
                ?: PosSeeds.DEFAULT_SETTINGS
        }

    val currentUserIdFlow: Flow<String?> =
        dao.observeKv(KV_CURRENT_USER_ID).map { it?.jsonValue }

    suspend fun ensureSeeded() = withContext(Dispatchers.IO) {
        if (dao.countProducts() == 0) {
            val seededProducts = loadCatalogFromAssets()
            if (seededProducts.isNotEmpty()) {
                dao.insertProducts(seededProducts.map { it.toEntity() })
            }
        }
        if (dao.countUsers() == 0) {
            dao.insertUsers(PosSeeds.DEFAULT_USERS.map { it.toEntity() })
        }
        if (dao.countCustomers() == 0) {
            dao.insertCustomers(PosSeeds.DEFAULT_CUSTOMERS.map { it.toEntity() })
        }
        if (dao.countSuppliers() == 0) {
            dao.insertSuppliers(PosSeeds.DEFAULT_SUPPLIERS.map { it.toEntity() })
        }
        if (dao.countCaisse() == 0) {
            dao.insertCaisseMovement(
                CaisseMovement(
                    id = "c_init",
                    date = nowIso(),
                    type = "entree",
                    motif = "Fond de caisse ouverture",
                    montant = 50000.0,
                    auteur = "Walid"
                ).toEntity()
            )
        }
        if (dao.getKv(KV_STORE_INFO) == null) {
            dao.putKv(AppKvEntity(KV_STORE_INFO, PosJsonMapper.storeInfoToJson(PosSeeds.DEFAULT_STORE_INFO)))
        }
        if (dao.getKv(KV_SETTINGS) == null) {
            dao.putKv(AppKvEntity(KV_SETTINGS, PosJsonMapper.settingsToJson(PosSeeds.DEFAULT_SETTINGS)))
        }
    }

    private fun loadCatalogFromAssets(): List<TileProduct> {
        return runCatching {
            val raw = context.assets.open("catalog_seed.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(raw)
            buildList(arr.length()) {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val name = o.optString("name")
                    val usine = o.optString("usine")
                    val dimension = o.optString("dimension")
                    val choix = o.optString("choix", "1er Choix")
                    val desc = o.optString("description").ifBlank {
                        "$name - Qualité garantie usine $usine, $dimension, $choix."
                    }
                    add(
                        TileProduct(
                            id = o.optString("id"),
                            name = name,
                            usine = usine,
                            dimension = dimension,
                            m2Carton = o.optDouble("m2_carton", 1.0),
                            pcs = o.optInt("pcs", 1),
                            prix = o.optDouble("prix", 0.0),
                            prixAchat = o.optDouble("prixAchat", 0.0),
                            stock = o.optInt("stock", 0),
                            color = o.optString("color", "#94a3b8"),
                            colorName = o.optString("colorName", "Gris Minéral"),
                            image = o.optString("image", ""),
                            finition = o.optString("finition", "brillant"),
                            choix = choix,
                            categorie = o.optString("categorie", "sol"),
                            description = desc
                        )
                    )
                }
            }
        }.getOrElse { emptyList() }
    }

    // Cloud Snapshot & Sync Helpers
    suspend fun getProductsSnapshot(): List<TileProduct> = dao.getProductsSnapshot().map { it.toModel() }
    suspend fun getUsersSnapshot(): List<StaffUser> = dao.getUsersSnapshot().map { it.toModel() }
    suspend fun getCustomersSnapshot(): List<Customer> = dao.getCustomersSnapshot().map { it.toModel() }
    suspend fun getSuppliersSnapshot(): List<Supplier> = dao.getSuppliersSnapshot().map { it.toModel() }
    suspend fun getCaisseSnapshot(): List<CaisseMovement> = dao.getCaisseSnapshot().map { it.toModel() }
    suspend fun getStoreInfoSnapshot(): StoreInfo = dao.getKv(KV_STORE_INFO)?.let {
        PosJsonMapper.jsonToStoreInfo(it.jsonValue, PosSeeds.DEFAULT_STORE_INFO)
    } ?: PosSeeds.DEFAULT_STORE_INFO
    suspend fun getSettingsSnapshot(): AppSettings = dao.getKv(KV_SETTINGS)?.let {
        PosJsonMapper.jsonToSettings(it.jsonValue, PosSeeds.DEFAULT_SETTINGS)
    } ?: PosSeeds.DEFAULT_SETTINGS

    suspend fun getUnreadNotificationIds(): List<String> =
        dao.getNotificationsSnapshot().filter { !it.read }.map { it.id }

    suspend fun replaceProductsFromCloud(items: List<TileProduct>) {
        db.withTransaction {
            dao.clearProducts()
            dao.insertProducts(items.map { it.toEntity() })
        }
    }

    suspend fun replaceInvoicesFromCloud(items: List<Invoice>) {
        db.withTransaction {
            dao.clearInvoices()
            dao.insertInvoices(items.map { it.toEntity() })
        }
    }

    suspend fun replaceCustomersFromCloud(items: List<Customer>) {
        db.withTransaction {
            dao.clearCustomers()
            dao.insertCustomers(items.map { it.toEntity() })
        }
    }

    suspend fun replaceSuppliersFromCloud(items: List<Supplier>) {
        db.withTransaction {
            dao.clearSuppliers()
            dao.insertSuppliers(items.map { it.toEntity() })
        }
    }

    suspend fun replaceSupplierMovementsFromCloud(items: List<SupplierMovement>) {
        db.withTransaction {
            dao.clearSupplierMovements()
            dao.insertSupplierMovements(items.map { it.toEntity() })
        }
    }

    suspend fun replaceCaisseFromCloud(items: List<CaisseMovement>) {
        db.withTransaction {
            dao.clearCaisse()
            dao.insertCaisseMovements(items.map { it.toEntity() })
        }
    }

    suspend fun replaceDailyCaisseCountsFromCloud(items: List<DailyCaisseCount>) {
        db.withTransaction {
            dao.clearDailyCaisseCounts()
            dao.insertDailyCaisseCounts(items.map { it.toEntity() })
        }
    }

    suspend fun replaceUsersFromCloud(items: List<StaffUser>) {
        db.withTransaction {
            dao.clearUsers()
            dao.insertUsers(items.map { it.toEntity() })
        }
    }

    suspend fun replaceNotificationsFromCloud(items: List<DepotNotification>) {
        db.withTransaction {
            dao.clearNotifications()
            dao.insertNotifications(items.map { it.toEntity() })
        }
    }

    suspend fun resetCatalogToDefault(): List<TileProduct> = withContext(Dispatchers.IO) {
        val seeded = loadCatalogFromAssets()
        db.withTransaction {
            dao.clearProducts()
            dao.insertProducts(seeded.map { it.toEntity() })
        }
        seeded
    }

    // Cart & Free Lines
    suspend fun saveCart(items: List<CartItem>) {
        dao.putKv(AppKvEntity(KV_CART, PosJsonMapper.cartItemsToJson(items)))
    }

    suspend fun saveFreeLines(lines: List<FreeLineItem>) {
        dao.putKv(AppKvEntity(KV_FREE_LINES, PosJsonMapper.freeLinesToJson(lines)))
    }

    suspend fun clearCartAndFreeLines() {
        db.withTransaction {
            dao.putKv(AppKvEntity(KV_CART, "[]"))
            dao.putKv(AppKvEntity(KV_FREE_LINES, "[]"))
        }
    }

    // Products
    suspend fun adjustProductStock(productId: String, delta: Int): Int? {
        dao.adjustProductStock(productId, delta)
        return dao.getProductsSnapshot().find { it.id == productId }?.stock
    }

    suspend fun setProductStock(productId: String, stock: Int): Int {
        val safeStock = stock.coerceAtLeast(0)
        dao.setProductStock(productId, safeStock)
        return safeStock
    }

    suspend fun upsertProduct(product: TileProduct) {
        dao.upsertProduct(product.toEntity())
    }

    suspend fun deleteProduct(productId: String) {
        dao.deleteProductById(productId)
    }

    // Invoices
    suspend fun saveNewInvoice(invoice: Invoice): SaleCommitResult {
        var createdCaisse: CaisseMovement? = null
        var updatedCustomer: Customer? = null
        val updatedStocks = mutableMapOf<String, Int>()
        lateinit var createdNotification: DepotNotification

        db.withTransaction {
            dao.upsertInvoice(invoice.toEntity())
            invoice.articles.forEach { item ->
                if (item.cartons > 0) {
                    dao.adjustProductStock(item.productId, -item.cartons)
                }
            }
            val currentProducts = dao.getProductsSnapshot()
            invoice.articles.forEach { item ->
                currentProducts.find { it.id == item.productId }?.let { p ->
                    updatedStocks[p.id] = p.stock
                }
            }
            if (invoice.montantPaye > 0) {
                val caisse = CaisseMovement(
                    id = "caisse_${System.currentTimeMillis()}_${shortId()}",
                    date = nowIso(),
                    type = "entree",
                    motif = "Vente #${invoice.reference} (${invoice.magasin}) - ${invoice.client.nom}",
                    montant = invoice.montantPaye,
                    auteur = invoice.vendeur,
                    referenceFacture = invoice.reference
                )
                dao.insertCaisseMovement(caisse.toEntity())
                createdCaisse = caisse
            }
            val clientId = invoice.client.id
            if (!clientId.isNullOrBlank()) {
                val existing = dao.getCustomersSnapshot().find { it.id == clientId }
                if (existing != null) {
                    val unpaid = (invoice.totalNet - invoice.montantPaye).coerceAtLeast(0.0)
                    val nextCustEntity = existing.copy(
                        dette = existing.dette + unpaid,
                        totalAchats = existing.totalAchats + invoice.totalNet
                    )
                    dao.upsertCustomer(nextCustEntity)
                    updatedCustomer = nextCustEntity.toModel()
                }
            }
            val m2Total = invoice.articles.sumOf { it.m2Total }
            val cartonsTotal = invoice.articles.sumOf { it.cartons }
            val summary = invoice.articles.joinToString(", ") {
                "${it.cartons} ctn ${it.name} (${formatM2(it.m2Total)}m²)"
            }
            val notif = DepotNotification(
                id = "notif_${System.currentTimeMillis()}_${shortId()}",
                invoiceId = invoice.id,
                reference = invoice.reference,
                date = nowIso(),
                vendeur = invoice.vendeur,
                magasin = invoice.magasin,
                client = invoice.client.nom,
                clientTel = invoice.client.tel,
                totalNet = invoice.totalNet,
                m2Total = m2Total,
                cartonsTotal = cartonsTotal,
                articlesSummary = summary,
                read = false
            )
            dao.insertNotification(notif.toEntity())
            createdNotification = notif
            dao.putKv(AppKvEntity(KV_CART, "[]"))
            dao.putKv(AppKvEntity(KV_FREE_LINES, "[]"))
        }
        return SaleCommitResult(
            invoice = invoice,
            caisseMovement = createdCaisse,
            updatedCustomer = updatedCustomer,
            notification = createdNotification,
            updatedProductStocks = updatedStocks
        )
    }

    suspend fun updateExistingInvoice(invoice: Invoice) {
        dao.upsertInvoice(invoice.toEntity())
    }

    suspend fun deleteInvoice(invoiceId: String) {
        dao.deleteInvoiceById(invoiceId)
    }

    // Notifications
    suspend fun markAllNotificationsRead() {
        dao.markAllNotificationsRead()
    }

    // Customers
    suspend fun upsertCustomer(customer: Customer) {
        dao.upsertCustomer(customer.toEntity())
    }

    suspend fun payCustomerDebt(
        customerId: String,
        amount: Double,
        author: String
    ): Pair<Customer, CaisseMovement>? {
        if (amount <= 0) return null
        var updatedCust: Customer? = null
        var caisseMov: CaisseMovement? = null
        db.withTransaction {
            val cust = dao.getCustomersSnapshot().find { it.id == customerId } ?: return@withTransaction
            val nextCust = cust.copy(dette = (cust.dette - amount).coerceAtLeast(0.0))
            dao.upsertCustomer(nextCust)
            val mov = CaisseMovement(
                id = "caisse_${System.currentTimeMillis()}_${shortId()}",
                date = nowIso(),
                type = "entree",
                motif = "Remboursement crédit client - ${cust.nom}",
                montant = amount,
                auteur = author
            )
            dao.insertCaisseMovement(mov.toEntity())
            updatedCust = nextCust.toModel()
            caisseMov = mov
        }
        val c = updatedCust
        val m = caisseMov
        return if (c != null && m != null) Pair(c, m) else null
    }

    // Suppliers
    suspend fun upsertSupplier(supplier: Supplier) {
        dao.upsertSupplier(supplier.toEntity())
    }

    suspend fun recordSupplierVersement(
        supplierId: String,
        amount: Double,
        motif: String,
        ref: String?,
        author: String
    ): Triple<Supplier, SupplierMovement, CaisseMovement>? {
        if (amount <= 0) return null
        var updatedSup: Supplier? = null
        var supMov: SupplierMovement? = null
        var caisseMov: CaisseMovement? = null
        db.withTransaction {
            val sup = dao.getSuppliersSnapshot().find { it.id == supplierId } ?: return@withTransaction
            val nextSup = sup.copy(soldeDette = (sup.soldeDette - amount).coerceAtLeast(0.0))
            dao.upsertSupplier(nextSup)
            val mov = SupplierMovement(
                id = "sup_mov_${System.currentTimeMillis()}_${shortId()}",
                supplierId = supplierId,
                date = nowIso(),
                type = "versement",
                montant = amount,
                motif = motif.ifBlank { "Versement / Règlement dette usine" },
                pieceJointeRef = ref?.takeIf { it.isNotBlank() },
                auteur = author
            )
            dao.insertSupplierMovement(mov.toEntity())
            val cMov = CaisseMovement(
                id = "caisse_${System.currentTimeMillis()}_${shortId()}",
                date = nowIso(),
                type = "sortie",
                motif = "Règlement usine ${sup.nom} : $motif",
                montant = amount,
                auteur = author
            )
            dao.insertCaisseMovement(cMov.toEntity())
            updatedSup = nextSup.toModel()
            supMov = mov
            caisseMov = cMov
        }
        val s = updatedSup
        val sm = supMov
        val cm = caisseMov
        return if (s != null && sm != null && cm != null) Triple(s, sm, cm) else null
    }

    suspend fun recordSupplierInvoice(
        supplierId: String,
        amount: Double,
        motif: String,
        ref: String?,
        author: String
    ): Pair<Supplier, SupplierMovement>? {
        if (amount <= 0) return null
        var updatedSup: Supplier? = null
        var supMov: SupplierMovement? = null
        db.withTransaction {
            val sup = dao.getSuppliersSnapshot().find { it.id == supplierId } ?: return@withTransaction
            val nextSup = sup.copy(
                soldeDette = sup.soldeDette + amount,
                totalAchats = sup.totalAchats + amount
            )
            dao.upsertSupplier(nextSup)
            val mov = SupplierMovement(
                id = "sup_mov_${System.currentTimeMillis()}_${shortId()}",
                supplierId = supplierId,
                date = nowIso(),
                type = "achat",
                montant = amount,
                motif = motif.ifBlank { "Réception Marchandise" },
                pieceJointeRef = ref?.takeIf { it.isNotBlank() },
                auteur = author
            )
            dao.insertSupplierMovement(mov.toEntity())
            updatedSup = nextSup.toModel()
            supMov = mov
        }
        val s = updatedSup
        val sm = supMov
        return if (s != null && sm != null) Pair(s, sm) else null
    }

    // Caisse
    suspend fun addCaisseMovement(movement: CaisseMovement) {
        dao.insertCaisseMovement(movement.toEntity())
    }

    suspend fun saveDailyCaisseCount(count: DailyCaisseCount) {
        dao.insertDailyCaisseCount(count.toEntity())
    }

    // Users & Session
    suspend fun setCurrentUserId(userId: String?) {
        dao.putKv(AppKvEntity(KV_CURRENT_USER_ID, userId ?: ""))
    }

    suspend fun upsertUser(user: StaffUser) {
        dao.upsertUser(user.toEntity())
    }

    suspend fun deleteUser(userId: String) {
        dao.deleteUserById(userId)
    }

    // Store Info & Settings
    suspend fun saveStoreInfo(info: StoreInfo) {
        dao.putKv(AppKvEntity(KV_STORE_INFO, PosJsonMapper.storeInfoToJson(info)))
    }

    suspend fun saveSettings(settings: AppSettings) {
        dao.putKv(AppKvEntity(KV_SETTINGS, PosJsonMapper.settingsToJson(settings)))
    }

    // Backup Export / Import JSON
    suspend fun exportAllDataJson(): String = withContext(Dispatchers.IO) {
        val storeInfo = dao.getKv(KV_STORE_INFO)?.let {
            PosJsonMapper.jsonToStoreInfo(it.jsonValue, PosSeeds.DEFAULT_STORE_INFO)
        } ?: PosSeeds.DEFAULT_STORE_INFO
        val settings = dao.getKv(KV_SETTINGS)?.let {
            PosJsonMapper.jsonToSettings(it.jsonValue, PosSeeds.DEFAULT_SETTINGS)
        } ?: PosSeeds.DEFAULT_SETTINGS

        val productsArr = JSONArray().apply {
            dao.getProductsSnapshot().map { it.toModel() }.forEach { p ->
                put(JSONObject().apply {
                    put("id", p.id)
                    put("name", p.name)
                    put("usine", p.usine)
                    put("dimension", p.dimension)
                    put("m2_carton", p.m2Carton)
                    put("pcs", p.pcs)
                    put("prix", p.prix)
                    put("prixAchat", p.prixAchat)
                    put("stock", p.stock)
                    put("color", p.color)
                    put("colorName", p.colorName)
                    put("image", p.image)
                    put("finition", p.finition)
                    put("choix", p.choix)
                    put("categorie", p.categorie)
                    put("description", p.description)
                })
            }
        }

        val invoicesArr = JSONArray().apply {
            dao.getInvoicesSnapshot().forEach { inv ->
                put(JSONObject().apply {
                    put("id", inv.id)
                    put("reference", inv.reference)
                    put("date", inv.date)
                    put("vendeur", inv.vendeur)
                    put("magasin", inv.magasin)
                    put("client", JSONObject(inv.clientJson))
                    put("articles", JSONArray(inv.articlesJson))
                    put("lignesLibres", JSONArray(inv.lignesLibresJson))
                    put("totalBrut", inv.totalBrut)
                    put("remise", inv.remise)
                    put("totalNet", inv.totalNet)
                    put("montantPaye", inv.montantPaye)
                    put("resteAPayer", inv.resteAPayer)
                    put("modePaiement", inv.modePaiement)
                    put("statut", inv.statut)
                    put("notes", inv.notes)
                })
            }
        }

        val customersArr = JSONArray().apply {
            dao.getCustomersSnapshot().forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id)
                    put("nom", c.nom)
                    put("tel", c.tel)
                    put("adresse", c.adresse)
                    put("dette", c.dette)
                    put("totalAchats", c.totalAchats)
                })
            }
        }

        val suppliersArr = JSONArray().apply {
            dao.getSuppliersSnapshot().forEach { s ->
                put(JSONObject().apply {
                    put("id", s.id)
                    put("nom", s.nom)
                    put("contact", s.contact)
                    put("tel", s.tel)
                    put("adresse", s.adresse)
                    put("usineRepresentee", s.usineRepresentee)
                    put("soldeDette", s.soldeDette)
                    put("totalAchats", s.totalAchats)
                })
            }
        }

        val caisseArr = JSONArray().apply {
            dao.getCaisseSnapshot().forEach { m ->
                put(JSONObject().apply {
                    put("id", m.id)
                    put("date", m.date)
                    put("type", m.type)
                    put("motif", m.motif)
                    put("montant", m.montant)
                    put("auteur", m.auteur)
                    put("referenceFacture", m.referenceFacture ?: JSONObject.NULL)
                })
            }
        }

        val usersArr = JSONArray().apply {
            dao.getUsersSnapshot().forEach { u ->
                put(JSONObject().apply {
                    put("id", u.id)
                    put("name", u.name)
                    put("role", u.role)
                    put("pin", u.pin)
                    put("magasin", u.magasin)
                    put("allowedTabs", JSONArray(u.allowedTabsJson))
                    put("canEditInvoices", u.canEditInvoices)
                    put("canDeleteInvoices", u.canDeleteInvoices)
                    put("canModifyStock", u.canModifyStock)
                    put("canViewSuppliers", u.canViewSuppliers)
                    put("canViewCaisse", u.canViewCaisse)
                    put("canManageUsers", u.canManageUsers)
                    put("active", u.active)
                })
            }
        }

        JSONObject().apply {
            put("exportDate", nowIso())
            put("storeInfo", JSONObject(PosJsonMapper.storeInfoToJson(storeInfo)))
            put("settings", JSONObject(PosJsonMapper.settingsToJson(settings)))
            put("products", productsArr)
            put("invoices", invoicesArr)
            put("customers", customersArr)
            put("suppliers", suppliersArr)
            put("caisse", caisseArr)
            put("users", usersArr)
        }.toString(2)
    }

    suspend fun importAllDataJson(jsonString: String): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val root = JSONObject(jsonString)
            db.withTransaction {
                root.optJSONObject("storeInfo")?.let {
                    dao.putKv(AppKvEntity(KV_STORE_INFO, it.toString()))
                }
                root.optJSONObject("settings")?.let {
                    dao.putKv(AppKvEntity(KV_SETTINGS, it.toString()))
                }
                root.optJSONArray("products")?.let { arr ->
                    val list = buildList {
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            add(
                                TileProduct(
                                    id = o.optString("id"),
                                    name = o.optString("name"),
                                    usine = o.optString("usine"),
                                    dimension = o.optString("dimension"),
                                    m2Carton = o.optDouble("m2_carton", o.optDouble("m2Carton", 1.0)),
                                    pcs = o.optInt("pcs", 1),
                                    prix = o.optDouble("prix", 0.0),
                                    prixAchat = o.optDouble("prixAchat", 0.0),
                                    stock = o.optInt("stock", 0),
                                    color = o.optString("color", "#94a3b8"),
                                    colorName = o.optString("colorName", ""),
                                    image = o.optString("image", ""),
                                    finition = o.optString("finition", "brillant"),
                                    choix = o.optString("choix", "1er Choix"),
                                    categorie = o.optString("categorie", "sol"),
                                    description = o.optString("description", "")
                                ).toEntity()
                            )
                        }
                    }
                    if (list.isNotEmpty()) {
                        dao.clearProducts()
                        dao.insertProducts(list)
                    }
                }
                root.optJSONArray("customers")?.let { arr ->
                    val list = buildList {
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            add(
                                Customer(
                                    id = o.optString("id"),
                                    nom = o.optString("nom"),
                                    tel = o.optString("tel"),
                                    adresse = o.optString("adresse"),
                                    dette = o.optDouble("dette", 0.0),
                                    totalAchats = o.optDouble("totalAchats", 0.0)
                                ).toEntity()
                            )
                        }
                    }
                    dao.clearCustomers()
                    dao.insertCustomers(list)
                }
                root.optJSONArray("suppliers")?.let { arr ->
                    val list = buildList {
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            add(
                                Supplier(
                                    id = o.optString("id"),
                                    nom = o.optString("nom"),
                                    contact = o.optString("contact"),
                                    tel = o.optString("tel"),
                                    adresse = o.optString("adresse"),
                                    usineRepresentee = o.optString("usineRepresentee"),
                                    soldeDette = o.optDouble("soldeDette", 0.0),
                                    totalAchats = o.optDouble("totalAchats", 0.0)
                                ).toEntity()
                            )
                        }
                    }
                    dao.clearSuppliers()
                    dao.insertSuppliers(list)
                }
                root.optJSONArray("caisse")?.let { arr ->
                    val list = buildList {
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            add(
                                CaisseMovement(
                                    id = o.optString("id"),
                                    date = o.optString("date"),
                                    type = o.optString("type"),
                                    motif = o.optString("motif"),
                                    montant = o.optDouble("montant", 0.0),
                                    auteur = o.optString("auteur"),
                                    referenceFacture = if (o.isNull("referenceFacture")) null else o.optString("referenceFacture")
                                ).toEntity()
                            )
                        }
                    }
                    dao.clearCaisse()
                    dao.insertCaisseMovements(list)
                }
                root.optJSONArray("invoices")?.let { arr ->
                    val list = buildList {
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            val clientObj = o.optJSONObject("client") ?: JSONObject()
                            val articlesArr = o.optJSONArray("articles") ?: JSONArray()
                            val freeArr = o.optJSONArray("lignesLibres") ?: JSONArray()
                            val client = PosJsonMapper.jsonToClient(clientObj.toString())
                            val articles = PosJsonMapper.jsonToCartItems(articlesArr.toString())
                            val free = PosJsonMapper.jsonToFreeLines(freeArr.toString())
                            add(
                                Invoice(
                                    id = o.optString("id"),
                                    reference = o.optString("reference"),
                                    date = o.optString("date"),
                                    vendeur = o.optString("vendeur"),
                                    magasin = o.optString("magasin", "Depot Remchi"),
                                    client = client,
                                    articles = articles,
                                    lignesLibres = free,
                                    totalBrut = o.optDouble("totalBrut", 0.0),
                                    remise = o.optDouble("remise", 0.0),
                                    totalNet = o.optDouble("totalNet", 0.0),
                                    montantPaye = o.optDouble("montantPaye", 0.0),
                                    resteAPayer = o.optDouble("resteAPayer", 0.0),
                                    modePaiement = o.optString("modePaiement", "Espèces"),
                                    statut = o.optString("statut", "Payé"),
                                    notes = o.optString("notes", "")
                                ).toEntity()
                            )
                        }
                    }
                    dao.clearInvoices()
                    dao.insertInvoices(list)
                }
                root.optJSONArray("users")?.let { arr ->
                    val list = buildList {
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            val tabsArr = o.optJSONArray("allowedTabs") ?: JSONArray()
                            val tabs = List(tabsArr.length()) { tabsArr.optString(it) }.filter { it.isNotBlank() }
                            add(
                                StaffUser(
                                    id = o.optString("id"),
                                    name = o.optString("name"),
                                    role = o.optString("role", "vendeur"),
                                    pin = o.optString("pin", "0000"),
                                    magasin = o.optString("magasin", "Depot Remchi"),
                                    allowedTabs = tabs,
                                    canEditInvoices = o.optBoolean("canEditInvoices", false),
                                    canDeleteInvoices = o.optBoolean("canDeleteInvoices", false),
                                    canModifyStock = o.optBoolean("canModifyStock", false),
                                    canViewSuppliers = o.optBoolean("canViewSuppliers", false),
                                    canViewCaisse = o.optBoolean("canViewCaisse", false),
                                    canManageUsers = o.optBoolean("canManageUsers", false),
                                    active = o.optBoolean("active", true)
                                ).toEntity()
                            )
                        }
                    }
                    if (list.isNotEmpty()) {
                        dao.clearUsers()
                        dao.insertUsers(list)
                    }
                }
            }
            true
        }.getOrDefault(false)
    }

    private fun nowIso(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }

    private fun shortId(): String = UUID.randomUUID().toString().take(6)
}
