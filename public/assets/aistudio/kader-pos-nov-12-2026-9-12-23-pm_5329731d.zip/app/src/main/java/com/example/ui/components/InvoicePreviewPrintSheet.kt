package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppSettings
import com.example.data.model.Invoice
import com.example.data.model.PosSeeds
import com.example.data.model.StoreInfo
import com.example.data.model.formatDa
import com.example.data.model.formatM2
import com.example.data.model.toDzWhatsAppDigits
import com.example.ui.theme.Amber400
import com.example.ui.theme.Amber500
import com.example.ui.theme.Cyan400
import com.example.ui.theme.Cyan950
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvoicePreviewPrintSheet(
    invoice: Invoice,
    storeInfo: StoreInfo,
    settings: AppSettings,
    onUpdateSettings: (AppSettings) -> Unit,
    onDismiss: () -> Unit
) {
    BackHandler { onDismiss() }
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var format by remember { mutableStateOf(settings.printFormat) }
    var density by remember { mutableStateOf(settings.a5Density) }
    var hideBain by remember { mutableStateOf(settings.hideBainTeinteFacture) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Slate950,
        contentColor = Slate100,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 680.dp)
                .align(Alignment.CenterHorizontally)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .testTag("invoice_preview_sheet"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Aperçu & Impression #${invoice.reference}",
                        style = MaterialTheme.typography.titleLarge,
                        color = Slate100,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "${invoice.magasin} • Vendeur: ${invoice.vendeur}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Cyan400
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Slate400)
                }
            }

            // Format & Density Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("A4", "A5").forEach { fmt ->
                    FilterChip(
                        selected = format == fmt,
                        onClick = {
                            format = fmt
                            onUpdateSettings(settings.copy(printFormat = fmt))
                        },
                        label = { Text(fmt, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Cyan950,
                            selectedLabelColor = Cyan400,
                            containerColor = Slate900,
                            labelColor = Slate400
                        )
                    )
                }
                if (format == "A5") {
                    listOf("ultra" to "Ultra", "compact" to "Compact", "normal" to "Normal").forEach { (key, label) ->
                        FilterChip(
                            selected = density == key,
                            onClick = {
                                density = key
                                onUpdateSettings(settings.copy(a5Density = key))
                            },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Amber500,
                                selectedLabelColor = Slate950,
                                containerColor = Slate900,
                                labelColor = Slate400
                            )
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Masquer Bain/Teinte sur facture client",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Slate100
                )
                Switch(
                    checked = hideBain,
                    onCheckedChange = {
                        hideBain = it
                        onUpdateSettings(settings.copy(hideBainTeinteFacture = it))
                    }
                )
            }

            // Paper Preview Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = Color.White,
                border = BorderStroke(1.dp, Slate700)
            ) {
                val pad = if (format == "A5" && density == "ultra") 10.dp else 16.dp
                Column(
                    modifier = Modifier.padding(pad),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = storeInfo.nom,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = storeInfo.nomArabe,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF0E7490)
                            )
                            Text(
                                text = storeInfo.adresse,
                                fontSize = 10.sp,
                                color = Color(0xFF475569)
                            )
                            Text(
                                text = "Tél: ${storeInfo.tel} / ${storeInfo.tel2}",
                                fontSize = 10.sp,
                                color = Color(0xFF334155)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "BON DE LIVRAISON / FACTURE",
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "N° ${invoice.reference}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFFB45309)
                            )
                            Text(
                                text = invoice.date.take(10),
                                fontSize = 10.sp,
                                color = Color(0xFF475569)
                            )
                            Text(
                                text = "Format: $format",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    HorizontalDivider(color = Color(0xFFCBD5E1))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF8FAFC), RoundedCornerShape(6.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("CLIENT: ${invoice.client.nom}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF0F172A))
                            if (invoice.client.tel.isNotBlank()) {
                                Text("Tél: ${invoice.client.tel}", fontSize = 10.sp, color = Color(0xFF475569))
                            }
                        }
                        Text(
                            text = invoice.statut.uppercase(),
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            color = if (invoice.resteAPayer <= 0) Color(0xFF047857) else Color(0xFFBE123C)
                        )
                    }

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A))
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text("Désignation", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2.2f))
                        Text("Qté", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                        Text("P.U", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f), textAlign = TextAlign.End)
                        Text("Total", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.1f), textAlign = TextAlign.End)
                    }

                    invoice.articles.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(2.2f)) {
                                Text(item.name, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                                val extra = buildString {
                                    append("${item.usine} • ${item.dimension}")
                                    if (!hideBain && item.bain.isNotBlank()) {
                                        append(" • Bain: ${item.bain}")
                                    }
                                }
                                Text(extra, fontSize = 9.sp, color = Color(0xFF64748B))
                            }
                            Text(
                                text = "${item.cartons} ctn\n${formatM2(item.m2Total)} m²",
                                fontSize = 9.sp,
                                color = Color(0xFF0F172A),
                                textAlign = TextAlign.End,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = item.prixUnitaire.toInt().toString(),
                                fontSize = 10.sp,
                                color = Color(0xFF334155),
                                textAlign = TextAlign.End,
                                modifier = Modifier.weight(0.9f)
                            )
                            Text(
                                text = formatDa(item.sousTotal),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A),
                                textAlign = TextAlign.End,
                                modifier = Modifier.weight(1.1f)
                            )
                        }
                        HorizontalDivider(color = Color(0xFFE2E8F0))
                    }

                    invoice.lignesLibres.forEach { line ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(line.designation, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF0F172A), modifier = Modifier.weight(2.2f))
                            Text("${formatM2(line.quantite)} ${line.unite}", fontSize = 9.sp, color = Color(0xFF0F172A), textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                            Text(line.prixUnitaire.toInt().toString(), fontSize = 10.sp, color = Color(0xFF334155), textAlign = TextAlign.End, modifier = Modifier.weight(0.9f))
                            Text(formatDa(line.sousTotal), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A), textAlign = TextAlign.End, modifier = Modifier.weight(1.1f))
                        }
                        HorizontalDivider(color = Color(0xFFE2E8F0))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Total Cartons: ${invoice.articles.sumOf { it.cartons }} ctn • Surface: ${formatM2(invoice.articles.sumOf { it.m2Total })} m²",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF475569)
                            )
                            Text(
                                text = "RC: ${storeInfo.rc} • NIF: ${storeInfo.nif}",
                                fontSize = 8.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            if (invoice.remise > 0) {
                                Text("Remise: -${formatDa(invoice.remise)}", fontSize = 10.sp, color = Color(0xFFBE123C))
                            }
                            Text("NET À PAYER: ${formatDa(invoice.totalNet)}", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
                            Text("Payé (${invoice.modePaiement}): ${formatDa(invoice.montantPaye)}", fontSize = 10.sp, color = Color(0xFF047857))
                            if (invoice.resteAPayer > 0) {
                                Text("Reste / Crédit: ${formatDa(invoice.resteAPayer)}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFBE123C))
                            }
                        }
                    }
                }
            }

            // Action Buttons: Print & WhatsApp
            Button(
                onClick = {
                    printInvoiceHtml(
                        context = context,
                        invoice = invoice,
                        storeInfo = storeInfo,
                        format = format,
                        density = density,
                        hideBain = hideBain
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("invoice_print_pdf_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Amber500, contentColor = Slate950)
            ) {
                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Imprimer / Enregistrer PDF ($format)", fontWeight = FontWeight.Black)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val msg = buildWhatsAppDepotMessage(invoice)
                        openWhatsApp(context, PosSeeds.WHATSAPP_DEPOT, msg)
                    },
                    modifier = Modifier.weight(1f).height(48.dp),
                    border = BorderStroke(1.dp, Cyan400),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = Cyan400, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WA Dépôt", color = Cyan400, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val msg = buildWhatsAppClientMessage(invoice, storeInfo)
                        val phone = toDzWhatsAppDigits(invoice.client.tel)
                        openWhatsApp(context, phone, msg)
                    },
                    modifier = Modifier.weight(1f).height(48.dp),
                    border = BorderStroke(1.dp, Emerald500),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = Emerald500, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WA Client", color = Emerald500, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val msg = buildWhatsAppPatronMessage(invoice)
                        openWhatsApp(context, PosSeeds.WHATSAPP_PATRON, msg)
                    },
                    modifier = Modifier.weight(1f).height(48.dp),
                    border = BorderStroke(1.dp, Amber400),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = Amber400, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WA Patron", color = Amber400, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

fun openWhatsApp(context: Context, phone213: String?, message: String) {
    val encoded = Uri.encode(message)
    val url = if (!phone213.isNullOrBlank()) {
        "https://wa.me/$phone213?text=$encoded"
    } else {
        "https://wa.me/?text=$encoded"
    }
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}

fun buildWhatsAppDepotMessage(invoice: Invoice): String {
    val lines = invoice.articles.joinToString("\n") {
        "• ${it.cartons} ctn (${formatM2(it.m2Total)} m²) - ${it.name} [${it.usine}]"
    }
    return buildString {
        appendLine("📦 *PRÉPARATION DÉPÔT - ${invoice.magasin}*")
        appendLine("Réf: #${invoice.reference} | Vendeur: ${invoice.vendeur}")
        appendLine("Client: ${invoice.client.nom}")
        appendLine("----------------------")
        appendLine(lines)
        appendLine("Total: ${invoice.articles.sumOf { it.cartons }} Cartons / ${formatM2(invoice.articles.sumOf { it.m2Total })} m²")
    }
}

fun buildWhatsAppClientMessage(invoice: Invoice, store: StoreInfo): String {
    val items = invoice.articles.joinToString("\n") {
        "• ${it.name}: ${it.cartons} ctn (${formatM2(it.m2Total)} m²) = ${formatDa(it.sousTotal)}"
    }
    return buildString {
        appendLine("🏛️ *${store.nom}*")
        appendLine("Facture #${invoice.reference} (${invoice.date.take(10)})")
        appendLine("Client: ${invoice.client.nom}")
        appendLine(items)
        if (invoice.lignesLibres.isNotEmpty()) {
            invoice.lignesLibres.forEach {
                appendLine("• ${it.designation}: ${formatM2(it.quantite)} ${it.unite} = ${formatDa(it.sousTotal)}")
            }
        }
        appendLine("----------------------")
        appendLine("Total Net: *${formatDa(invoice.totalNet)}*")
        appendLine("Payé: ${formatDa(invoice.montantPaye)} | Reste: ${formatDa(invoice.resteAPayer)}")
        appendLine("Merci de votre confiance !")
    }
}

fun buildWhatsAppPatronMessage(invoice: Invoice): String {
    return "📊 *VENTE #${invoice.reference}* (${invoice.magasin})\n" +
        "Vendeur: ${invoice.vendeur} | Client: ${invoice.client.nom}\n" +
        "Total Net: ${formatDa(invoice.totalNet)} | Encaissé: ${formatDa(invoice.montantPaye)} (${invoice.modePaiement})\n" +
        "Reste: ${formatDa(invoice.resteAPayer)}"
}

private fun printInvoiceHtml(
    context: Context,
    invoice: Invoice,
    storeInfo: StoreInfo,
    format: String,
    density: String,
    hideBain: Boolean
) {
    val fontSize = when {
        format == "A5" && density == "ultra" -> "9px"
        format == "A5" && density == "compact" -> "10px"
        else -> "12px"
    }
    val rowsHtml = buildString {
        invoice.articles.forEach { item ->
            val bainStr = if (!hideBain && item.bain.isNotBlank()) " (Bain: ${item.bain})" else ""
            append(
                "<tr>" +
                    "<td><b>${escapeHtml(item.name)}</b><br><small>${escapeHtml(item.usine)} • ${escapeHtml(item.dimension)}${escapeHtml(bainStr)}</small></td>" +
                    "<td style='text-align:right'>${item.cartons} ctn<br>${formatM2(item.m2Total)} m²</td>" +
                    "<td style='text-align:right'>${item.prixUnitaire.toInt()}</td>" +
                    "<td style='text-align:right'><b>${formatDa(item.sousTotal)}</b></td>" +
                    "</tr>"
            )
        }
        invoice.lignesLibres.forEach { line ->
            append(
                "<tr>" +
                    "<td><b>${escapeHtml(line.designation)}</b></td>" +
                    "<td style='text-align:right'>${formatM2(line.quantite)} ${escapeHtml(line.unite)}</td>" +
                    "<td style='text-align:right'>${line.prixUnitaire.toInt()}</td>" +
                    "<td style='text-align:right'><b>${formatDa(line.sousTotal)}</b></td>" +
                    "</tr>"
            )
        }
    }

    val html = """
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8" />
          <style>
            body { font-family: sans-serif; font-size: $fontSize; color: #0f172a; margin: 14px; }
            .header { display: flex; justify-content: space-between; border-bottom: 2px solid #0f172a; padding-bottom: 8px; margin-bottom: 10px; }
            .brand { font-size: 18px; font-weight: 900; }
            .ar { color: #0e7490; font-weight: bold; }
            table { width: 100%; border-collapse: collapse; margin-top: 8px; }
            th { background: #0f172a; color: #fff; text-align: left; padding: 5px; }
            td { border-bottom: 1px solid #e2e8f0; padding: 5px; vertical-align: top; }
            .totals { margin-top: 12px; text-align: right; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <div class="brand">${escapeHtml(storeInfo.nom)}</div>
              <div class="ar">${escapeHtml(storeInfo.nomArabe)}</div>
              <div>${escapeHtml(storeInfo.adresse)}</div>
              <div>Tél: ${escapeHtml(storeInfo.tel)} / ${escapeHtml(storeInfo.tel2)}</div>
            </div>
            <div style="text-align:right">
              <div><b>FACTURE N° ${escapeHtml(invoice.reference)}</b></div>
              <div>Date: ${escapeHtml(invoice.date.take(10))}</div>
              <div>Site: ${escapeHtml(invoice.magasin)}</div>
              <div>Vendeur: ${escapeHtml(invoice.vendeur)}</div>
            </div>
          </div>
          <div><b>Client:</b> ${escapeHtml(invoice.client.nom)} ${if (invoice.client.tel.isNotBlank()) "— ${escapeHtml(invoice.client.tel)}" else ""}</div>
          <table>
            <thead>
              <tr><th>Désignation</th><th style="text-align:right">Qté</th><th style="text-align:right">P.U</th><th style="text-align:right">Total</th></tr>
            </thead>
            <tbody>$rowsHtml</tbody>
          </table>
          <div class="totals">
            ${if (invoice.remise > 0) "<div>Remise: -${formatDa(invoice.remise)}</div>" else ""}
            <div style="font-size:15px;font-weight:900">TOTAL NET: ${formatDa(invoice.totalNet)}</div>
            <div>Payé (${escapeHtml(invoice.modePaiement)}): ${formatDa(invoice.montantPaye)}</div>
            ${if (invoice.resteAPayer > 0) "<div style='color:#be123c;font-weight:bold'>Reste à payer: ${formatDa(invoice.resteAPayer)}</div>" else ""}
          </div>
        </body>
        </html>
    """.trimIndent()

    val webView = WebView(context)
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
            val adapter = view?.createPrintDocumentAdapter("Facture_${invoice.reference}") ?: return
            val mediaSize = if (format == "A5") PrintAttributes.MediaSize.ISO_A5 else PrintAttributes.MediaSize.ISO_A4
            printManager.print(
                "Facture_${invoice.reference}",
                adapter,
                PrintAttributes.Builder().setMediaSize(mediaSize).build()
            )
        }
    }
    webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
}

private fun escapeHtml(text: String): String =
    text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
