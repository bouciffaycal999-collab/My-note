package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppSettings
import com.example.data.model.CaisseMovement
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.DailyCaisseCount
import com.example.data.model.DepotNotification
import com.example.data.model.FreeLineItem
import com.example.data.model.Invoice
import com.example.data.model.InvoiceClient
import com.example.data.model.PosSeeds
import com.example.data.model.StaffUser
import com.example.data.model.StoreInfo
import com.example.data.model.Supplier
import com.example.data.model.SupplierMovement
import com.example.data.model.TileProduct
import com.example.data.remote.FirestorePosRepository
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.example.data.remote.unwrapFirestoreException
import com.example.data.repository.PosRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import kotlin.math.roundToInt

data class CalculatorTarget(
    val product: TileProduct? = null,
    val editingCartItem: CartItem? = null
)

data class PosUiState(
    val isLoading: Boolean = true,
    val products: List<TileProduct> = emptyList(),
    val invoices: List<Invoice> = emptyList(),
    val customers: List<Customer> = emptyList(),
    val suppliers: List<Supplier> = emptyList(),
    val supplierMovements: List<SupplierMovement> = emptyList(),
    val caisseMovements: List<CaisseMovement> = emptyList(),
    val dailyCaisseCounts: List<DailyCaisseCount> = emptyList(),
    val users: List<StaffUser> = emptyList(),
    val notifications: List<DepotNotification> = emptyList(),
    val cart: List<CartItem> = emptyList(),
    val freeLines: List<FreeLineItem> = emptyList(),
    val storeInfo: StoreInfo = PosSeeds.DEFAULT_STORE_INFO,
    val settings: AppSettings = PosSeeds.DEFAULT_SETTINGS,
    val currentUser: StaffUser? = null,
    val isLocked: Boolean = true,
    val pinError: String? = null,
    val activeTab: String = "pos",
    val calculatorTarget: CalculatorTarget? = null,
    val previewInvoice: Invoice? = null,
    val showNotificationsSheet: Boolean = false,
    val editingInvoice: Invoice? = null,
    val statusMessage: String? = null,
    val firebaseUserEmail: String? = null,
    val isCloudSynced: Boolean = false,
    val cloudSyncError: String? = null
) {
    val unreadNotificationsCount: Int get() = notifications.count { !it.read }
    val cartTotalBrut: Double
        get() = cart.sumOf { it.sousTotal } + freeLines.sumOf { it.sousTotal }
    val cartTotalM2: Double
        get() = cart.sumOf { it.m2Total }
    val cartTotalCartons: Int
        get() = cart.sumOf { it.cartons }
    val caisseSolde: Double
        get() = caisseMovements.sumOf { if (it.type == "entree") it.montant else -it.montant }
}

private data class LocalNavState(
    val isReady: Boolean = false,
    val isLocked: Boolean = true,
    val pinError: String? = null,
    val activeTab: String = "pos",
    val calculatorTarget: CalculatorTarget? = null,
    val previewInvoice: Invoice? = null,
    val showNotificationsSheet: Boolean = false,
    val editingInvoice: Invoice? = null,
    val statusMessage: String? = null,
    val isCloudSynced: Boolean = false,
    val cloudSyncError: String? = null
)

class PosViewModel(
    private val repository: PosRepository,
    private val firestoreRepo: FirestorePosRepository,
    private val currentUserId: String,
    private val userEmail: String?,
    private val userDisplayName: String?
) : ViewModel() {

    private val navState = MutableStateFlow(LocalNavState())

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
            navState.value = navState.value.copy(isReady = true)
            bootstrapAndObserveCloud()
        }
    }

    private suspend fun bootstrapAndObserveCloud() {
        try {
            firestoreRepo.ensureUserAccount(currentUserId, userEmail, userDisplayName)
            firestoreRepo.seedDefaultsIfEmpty(
                userId = currentUserId,
                staffUsers = repository.getUsersSnapshot(),
                customers = repository.getCustomersSnapshot(),
                suppliers = repository.getSuppliersSnapshot(),
                caisseMovements = repository.getCaisseSnapshot(),
                storeInfo = repository.getStoreInfoSnapshot(),
                settings = repository.getSettingsSnapshot()
            )
            firestoreRepo.seedProductsIfEmpty(
                userId = currentUserId,
                products = repository.getProductsSnapshot()
            )
            navState.value = navState.value.copy(isCloudSynced = true, cloudSyncError = null)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val root = e.unwrapFirestoreException() ?: e
            Log.w(TAG, "Cloud bootstrap warning", root)
            navState.value = navState.value.copy(
                cloudSyncError = root.message ?: "Synchronisation cloud en attente"
            )
        }

        collectCloudStream(
            path = "users/$currentUserId/products",
            flow = firestoreRepo.observeProducts(currentUserId)
        ) { items ->
            if (items.isNotEmpty()) repository.replaceProductsFromCloud(items)
        }
        collectCloudStream(
            path = "users/$currentUserId/invoices",
            flow = firestoreRepo.observeInvoices(currentUserId)
        ) { items ->
            repository.replaceInvoicesFromCloud(items)
        }
        collectCloudStream(
            path = "users/$currentUserId/customers",
            flow = firestoreRepo.observeCustomers(currentUserId)
        ) { items ->
            if (items.isNotEmpty()) repository.replaceCustomersFromCloud(items)
        }
        collectCloudStream(
            path = "users/$currentUserId/suppliers",
            flow = firestoreRepo.observeSuppliers(currentUserId)
        ) { items ->
            if (items.isNotEmpty()) repository.replaceSuppliersFromCloud(items)
        }
        collectCloudStream(
            path = "users/$currentUserId/supplier_movements",
            flow = firestoreRepo.observeSupplierMovements(currentUserId)
        ) { items ->
            repository.replaceSupplierMovementsFromCloud(items)
        }
        collectCloudStream(
            path = "users/$currentUserId/caisse_movements",
            flow = firestoreRepo.observeCaisseMovements(currentUserId)
        ) { items ->
            if (items.isNotEmpty()) repository.replaceCaisseFromCloud(items)
        }
        collectCloudStream(
            path = "users/$currentUserId/daily_caisse_counts",
            flow = firestoreRepo.observeDailyCaisseCounts(currentUserId)
        ) { items ->
            repository.replaceDailyCaisseCountsFromCloud(items)
        }
        collectCloudStream(
            path = "users/$currentUserId/staff_users",
            flow = firestoreRepo.observeStaffUsers(currentUserId)
        ) { items ->
            if (items.isNotEmpty()) repository.replaceUsersFromCloud(items)
        }
        collectCloudStream(
            path = "users/$currentUserId/notifications",
            flow = firestoreRepo.observeNotifications(currentUserId)
        ) { items ->
            repository.replaceNotificationsFromCloud(items)
        }
        collectCloudStream(
            path = "users/$currentUserId/store_info/default",
            flow = firestoreRepo.observeStoreInfo(currentUserId)
        ) { info ->
            if (info != null) repository.saveStoreInfo(info)
        }
        collectCloudStream(
            path = "users/$currentUserId/app_settings/default",
            flow = firestoreRepo.observeAppSettings(currentUserId)
        ) { settings ->
            if (settings != null) repository.saveSettings(settings)
        }
    }

    private fun <T> collectCloudStream(
        path: String,
        flow: Flow<T>,
        onEachValue: suspend (T) -> Unit
    ) {
        viewModelScope.launch {
            flow
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val rootError = firestoreError ?: error
                    handleFirestoreError(rootError, OperationType.LIST, path)
                    navState.value = navState.value.copy(
                        isCloudSynced = false,
                        cloudSyncError = rootError.message ?: "Erreur de synchronisation cloud"
                    )
                }
                .collect { value ->
                    onEachValue(value)
                    if (!navState.value.isCloudSynced || navState.value.cloudSyncError != null) {
                        navState.value = navState.value.copy(isCloudSynced = true, cloudSyncError = null)
                    }
                }
        }
    }

    private suspend fun runCloudSync(
        operationType: OperationType,
        path: String,
        block: suspend () -> Unit
    ) {
        try {
            block()
            if (navState.value.cloudSyncError != null) {
                navState.value = navState.value.copy(isCloudSynced = true, cloudSyncError = null)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val root = e.unwrapFirestoreException() ?: e
            handleFirestoreError(root, operationType, path)
            navState.value = navState.value.copy(
                cloudSyncError = root.message ?: "Erreur sync cloud"
            )
        }
    }

    private val coreDataFlow = combine(
        repository.productsFlow,
        repository.invoicesFlow,
        repository.customersFlow,
        repository.suppliersFlow,
        repository.supplierMovementsFlow
    ) { products, invoices, customers, suppliers, supMoves ->
        CoreBundle(products, invoices, customers, suppliers, supMoves)
    }

    private val opsDataFlow = combine(
        repository.caisseFlow,
        repository.dailyCaisseCountsFlow,
        repository.usersFlow,
        repository.notificationsFlow,
        repository.currentUserIdFlow
    ) { caisse, dailyCounts, users, notifications, currentUserId ->
        OpsBundle(caisse, dailyCounts, users, notifications, currentUserId)
    }

    private val sessionDataFlow = combine(
        repository.cartFlow,
        repository.freeLinesFlow,
        repository.storeInfoFlow,
        repository.settingsFlow
    ) { cart, freeLines, storeInfo, settings ->
        SessionBundle(cart, freeLines, storeInfo, settings)
    }

    val uiState: StateFlow<PosUiState> = combine(
        coreDataFlow,
        opsDataFlow,
        sessionDataFlow,
        navState
    ) { core, ops, session, nav ->
        val matchedUser = ops.users.find { it.id == ops.currentUserId && it.active }
            ?: ops.users.firstOrNull { it.active }
        val resolvedTab = if (matchedUser != null && !matchedUser.allowedTabs.contains(nav.activeTab)) {
            matchedUser.allowedTabs.firstOrNull() ?: "pos"
        } else {
            nav.activeTab
        }
        PosUiState(
            isLoading = !nav.isReady,
            products = core.products,
            invoices = core.invoices,
            customers = core.customers,
            suppliers = core.suppliers,
            supplierMovements = core.supMoves,
            caisseMovements = ops.caisse,
            dailyCaisseCounts = ops.dailyCounts,
            users = ops.users,
            notifications = ops.notifications,
            cart = session.cart,
            freeLines = session.freeLines,
            storeInfo = session.storeInfo,
            settings = session.settings,
            currentUser = matchedUser,
            isLocked = nav.isLocked || ops.currentUserId.isNullOrBlank(),
            pinError = nav.pinError,
            activeTab = resolvedTab,
            calculatorTarget = nav.calculatorTarget,
            previewInvoice = nav.previewInvoice,
            showNotificationsSheet = nav.showNotificationsSheet,
            editingInvoice = nav.editingInvoice,
            statusMessage = nav.statusMessage,
            firebaseUserEmail = userEmail,
            isCloudSynced = nav.isCloudSynced,
            cloudSyncError = nav.cloudSyncError
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = PosUiState(firebaseUserEmail = userEmail)
    )

    fun attemptUnlock(user: StaffUser, enteredPin: String) {
        if (enteredPin == user.pin) {
            viewModelScope.launch {
                repository.setCurrentUserId(user.id)
                val firstTab = if (user.allowedTabs.contains("pos")) "pos" else user.allowedTabs.firstOrNull() ?: "pos"
                navState.value = navState.value.copy(
                    isLocked = false,
                    pinError = null,
                    activeTab = firstTab
                )
            }
        } else {
            navState.value = navState.value.copy(pinError = "Code PIN incorrect pour ${user.name}")
        }
    }

    fun lockSession() {
        navState.value = navState.value.copy(isLocked = true, pinError = null)
    }

    fun clearPinError() {
        if (navState.value.pinError != null) {
            navState.value = navState.value.copy(pinError = null)
        }
    }

    fun selectTab(tab: String) {
        navState.value = navState.value.copy(activeTab = tab)
    }

    fun openStandaloneCalculator() {
        navState.value = navState.value.copy(calculatorTarget = CalculatorTarget())
    }

    fun openProductCalculator(product: TileProduct) {
        navState.value = navState.value.copy(calculatorTarget = CalculatorTarget(product = product))
    }

    fun openCartItemCalculator(item: CartItem) {
        val product = uiState.value.products.find { it.id == item.productId } ?: TileProduct(
            id = item.productId,
            name = item.name,
            usine = item.usine,
            dimension = item.dimension,
            m2Carton = item.m2Carton,
            pcs = item.pcs,
            prix = item.prixUnitaire,
            prixAchat = item.prixAchat,
            stock = 0,
            color = item.color,
            colorName = item.colorName,
            image = item.image
        )
        navState.value = navState.value.copy(
            calculatorTarget = CalculatorTarget(product = product, editingCartItem = item)
        )
    }

    fun closeCalculator() {
        navState.value = navState.value.copy(calculatorTarget = null)
    }

    fun openInvoicePreview(invoice: Invoice) {
        navState.value = navState.value.copy(previewInvoice = invoice)
    }

    fun closeInvoicePreview() {
        navState.value = navState.value.copy(previewInvoice = null)
    }

    fun openNotificationsSheet() {
        navState.value = navState.value.copy(showNotificationsSheet = true)
    }

    fun closeNotificationsSheet() {
        navState.value = navState.value.copy(showNotificationsSheet = false)
        viewModelScope.launch {
            val unreadIds = repository.getUnreadNotificationIds()
            repository.markAllNotificationsRead()
            if (unreadIds.isNotEmpty()) {
                runCloudSync(OperationType.UPDATE, "users/$currentUserId/notifications") {
                    firestoreRepo.markAllNotificationsRead(currentUserId, unreadIds)
                }
            }
        }
    }

    fun clearStatusMessage() {
        navState.value = navState.value.copy(statusMessage = null)
    }

    private fun showMessage(msg: String) {
        navState.value = navState.value.copy(statusMessage = msg)
    }

    // Cart Operations
    fun quickAddOneCarton(product: TileProduct) {
        viewModelScope.launch {
            val currentCart = uiState.value.cart.toMutableList()
            val existingIdx = currentCart.indexOfFirst {
                it.productId == product.id && it.bain.isBlank() && it.pieces == 0 && it.prixUnitaire == product.prix
            }
            if (existingIdx >= 0) {
                val existing = currentCart[existingIdx]
                val nextCartons = existing.cartons + 1
                val nextM2 = round2(nextCartons * existing.m2Carton)
                currentCart[existingIdx] = existing.copy(
                    cartons = nextCartons,
                    m2Total = nextM2,
                    sousTotal = round2(nextM2 * existing.prixUnitaire)
                )
            } else {
                val m2 = round2(product.m2Carton)
                currentCart.add(
                    CartItem(
                        id = "line_${UUID.randomUUID().toString().take(8)}",
                        productId = product.id,
                        name = product.name,
                        usine = product.usine,
                        dimension = product.dimension,
                        m2Carton = product.m2Carton,
                        pcs = product.pcs,
                        prixUnitaire = product.prix,
                        prixAchat = product.prixAchat,
                        cartons = 1,
                        pieces = 0,
                        m2Total = m2,
                        sousTotal = round2(m2 * product.prix),
                        color = product.color,
                        colorName = product.colorName,
                        image = product.image
                    )
                )
            }
            repository.saveCart(currentCart)
        }
    }

    fun confirmCalculatorToCart(
        product: TileProduct,
        cartons: Int,
        pieces: Int,
        m2Total: Double,
        prixPerM2: Double,
        bain: String,
        calibre: String,
        editingItemId: String?
    ) {
        viewModelScope.launch {
            val currentCart = uiState.value.cart.toMutableList()
            val cleanM2 = round2(m2Total)
            val total = round2(cleanM2 * prixPerM2)
            if (editingItemId != null) {
                val idx = currentCart.indexOfFirst { it.id == editingItemId }
                if (idx >= 0) {
                    currentCart[idx] = currentCart[idx].copy(
                        cartons = cartons,
                        pieces = pieces,
                        m2Total = cleanM2,
                        prixUnitaire = prixPerM2,
                        sousTotal = total,
                        bain = bain,
                        calibre = calibre
                    )
                }
            } else {
                currentCart.add(
                    CartItem(
                        id = "line_${UUID.randomUUID().toString().take(8)}",
                        productId = product.id,
                        name = product.name,
                        usine = product.usine,
                        dimension = product.dimension,
                        m2Carton = product.m2Carton,
                        pcs = product.pcs,
                        prixUnitaire = prixPerM2,
                        prixAchat = product.prixAchat,
                        cartons = cartons,
                        pieces = pieces,
                        m2Total = cleanM2,
                        sousTotal = total,
                        bain = bain,
                        calibre = calibre,
                        color = product.color,
                        colorName = product.colorName,
                        image = product.image
                    )
                )
            }
            repository.saveCart(currentCart)
            navState.value = navState.value.copy(calculatorTarget = null)
        }
    }

    fun adjustCartItemCartons(itemId: String, delta: Int) {
        viewModelScope.launch {
            val currentCart = uiState.value.cart.mapNotNull { item ->
                if (item.id != itemId) item
                else {
                    val nextCartons = (item.cartons + delta).coerceAtLeast(0)
                    if (nextCartons == 0 && item.pieces == 0) null
                    else {
                        val safePcs = item.pcs.coerceAtLeast(1)
                        val m2Piece = item.m2Carton / safePcs
                        val nextM2 = round2((nextCartons * item.m2Carton) + (item.pieces * m2Piece))
                        item.copy(
                            cartons = nextCartons,
                            m2Total = nextM2,
                            sousTotal = round2(nextM2 * item.prixUnitaire)
                        )
                    }
                }
            }
            repository.saveCart(currentCart)
        }
    }

    fun removeCartItem(itemId: String) {
        viewModelScope.launch {
            repository.saveCart(uiState.value.cart.filterNot { it.id == itemId })
        }
    }

    fun addFreeLine(line: FreeLineItem) {
        viewModelScope.launch {
            repository.saveFreeLines(uiState.value.freeLines + line)
            navState.value = navState.value.copy(calculatorTarget = null)
        }
    }

    fun removeFreeLine(lineId: String) {
        viewModelScope.launch {
            repository.saveFreeLines(uiState.value.freeLines.filterNot { it.id == lineId })
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCartAndFreeLines()
            navState.value = navState.value.copy(editingInvoice = null)
        }
    }

    // Checkout & Invoices
    fun finalizeSale(
        client: InvoiceClient,
        remise: Double,
        montantPaye: Double,
        modePaiement: String,
        notes: String
    ) {
        val state = uiState.value
        val articles = state.cart
        val freeLines = state.freeLines
        if (articles.isEmpty() && freeLines.isEmpty()) return

        val totalBrut = round2(articles.sumOf { it.sousTotal } + freeLines.sumOf { it.sousTotal })
        val cleanRemise = remise.coerceIn(0.0, totalBrut)
        val totalNet = round2((totalBrut - cleanRemise).coerceAtLeast(0.0))
        val cleanPaye = if (modePaiement == "Crédit") 0.0 else montantPaye.coerceIn(0.0, totalNet)
        val reste = round2((totalNet - cleanPaye).coerceAtLeast(0.0))
        val statut = when {
            reste <= 0.01 -> "Payé"
            cleanPaye > 0.0 -> "Partiel"
            else -> "Crédit"
        }
        val editing = state.editingInvoice
        val invoice = if (editing != null) {
            editing.copy(
                client = client,
                articles = articles,
                lignesLibres = freeLines,
                totalBrut = totalBrut,
                remise = cleanRemise,
                totalNet = totalNet,
                montantPaye = cleanPaye,
                resteAPayer = reste,
                modePaiement = modePaiement,
                statut = statut,
                notes = notes
            )
        } else {
            val dateCode = SimpleDateFormat("yyMMdd", Locale.US).format(Date())
            val seq = (state.invoices.size + 1).toString().padStart(3, '0')
            Invoice(
                id = "inv_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(4)}",
                reference = "KC-$dateCode-$seq",
                date = nowIso(),
                vendeur = state.currentUser?.name ?: "Vendeur",
                magasin = state.settings.activeStore,
                client = client,
                articles = articles,
                lignesLibres = freeLines,
                totalBrut = totalBrut,
                remise = cleanRemise,
                totalNet = totalNet,
                montantPaye = cleanPaye,
                resteAPayer = reste,
                modePaiement = modePaiement,
                statut = statut,
                notes = notes
            )
        }

        viewModelScope.launch {
            if (editing != null) {
                repository.updateExistingInvoice(invoice)
                repository.clearCartAndFreeLines()
                runCloudSync(OperationType.UPDATE, "users/$currentUserId/invoices/${invoice.id}") {
                    firestoreRepo.upsertInvoice(currentUserId, invoice)
                }
            } else {
                val commit = repository.saveNewInvoice(invoice)
                runCloudSync(OperationType.WRITE, "users/$currentUserId/invoices/${commit.invoice.id}") {
                    firestoreRepo.upsertInvoice(currentUserId, commit.invoice)
                    commit.updatedProductStocks.forEach { (prodId, newStock) ->
                        firestoreRepo.updateProductStock(currentUserId, prodId, newStock)
                    }
                    commit.caisseMovement?.let { firestoreRepo.createCaisseMovement(currentUserId, it) }
                    commit.updatedCustomer?.let { firestoreRepo.upsertCustomer(currentUserId, it) }
                    firestoreRepo.createNotification(currentUserId, commit.notification)
                }
            }
            navState.value = navState.value.copy(
                editingInvoice = null,
                previewInvoice = invoice,
                statusMessage = if (editing != null) "Facture #${invoice.reference} modifiée" else "Facture #${invoice.reference} enregistrée"
            )
        }
    }

    fun startEditingInvoice(invoice: Invoice) {
        viewModelScope.launch {
            repository.saveCart(invoice.articles)
            repository.saveFreeLines(invoice.lignesLibres)
            navState.value = navState.value.copy(
                editingInvoice = invoice,
                activeTab = "pos",
                statusMessage = "Modification de #${invoice.reference}"
            )
        }
    }

    fun deleteInvoice(invoiceId: String) {
        viewModelScope.launch {
            repository.deleteInvoice(invoiceId)
            showMessage("Facture supprimée")
            runCloudSync(OperationType.DELETE, "users/$currentUserId/invoices/$invoiceId") {
                firestoreRepo.deleteInvoice(currentUserId, invoiceId)
            }
        }
    }

    // Stock
    fun adjustStock(productId: String, delta: Int) {
        viewModelScope.launch {
            val newStock = repository.adjustProductStock(productId, delta)
            if (newStock != null) {
                runCloudSync(OperationType.UPDATE, "users/$currentUserId/products/$productId") {
                    firestoreRepo.updateProductStock(currentUserId, productId, newStock)
                }
            }
        }
    }

    fun setStock(productId: String, stock: Int) {
        viewModelScope.launch {
            val newStock = repository.setProductStock(productId, stock)
            runCloudSync(OperationType.UPDATE, "users/$currentUserId/products/$productId") {
                firestoreRepo.updateProductStock(currentUserId, productId, newStock)
            }
        }
    }

    fun saveProduct(product: TileProduct) {
        viewModelScope.launch {
            repository.upsertProduct(product)
            showMessage("Fiche produit enregistrée")
            runCloudSync(OperationType.WRITE, "users/$currentUserId/products/${product.id}") {
                firestoreRepo.upsertProduct(currentUserId, product)
            }
        }
    }

    // Customers
    fun saveCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.upsertCustomer(customer)
            showMessage("Client enregistré")
            runCloudSync(OperationType.WRITE, "users/$currentUserId/customers/${customer.id}") {
                firestoreRepo.upsertCustomer(currentUserId, customer)
            }
        }
    }

    fun payCustomerDebt(customerId: String, amount: Double) {
        val author = uiState.value.currentUser?.name ?: "Gérant"
        viewModelScope.launch {
            val res = repository.payCustomerDebt(customerId, amount, author)
            showMessage("Remboursement encaissé en caisse")
            if (res != null) {
                val (cust, mov) = res
                runCloudSync(OperationType.WRITE, "users/$currentUserId/customers/$customerId") {
                    firestoreRepo.upsertCustomer(currentUserId, cust)
                    firestoreRepo.createCaisseMovement(currentUserId, mov)
                }
            }
        }
    }

    // Suppliers
    fun saveSupplier(supplier: Supplier) {
        viewModelScope.launch {
            repository.upsertSupplier(supplier)
            showMessage("Fournisseur enregistré")
            runCloudSync(OperationType.WRITE, "users/$currentUserId/suppliers/${supplier.id}") {
                firestoreRepo.upsertSupplier(currentUserId, supplier)
            }
        }
    }

    fun recordSupplierVersement(supplierId: String, amount: Double, motif: String, ref: String?) {
        val author = uiState.value.currentUser?.name ?: "Gérant"
        viewModelScope.launch {
            val res = repository.recordSupplierVersement(supplierId, amount, motif, ref, author)
            showMessage("Versement usine validé & déduit de la caisse")
            if (res != null) {
                val (sup, supMov, caisseMov) = res
                runCloudSync(OperationType.WRITE, "users/$currentUserId/suppliers/$supplierId") {
                    firestoreRepo.upsertSupplier(currentUserId, sup)
                    firestoreRepo.createSupplierMovement(currentUserId, supMov)
                    firestoreRepo.createCaisseMovement(currentUserId, caisseMov)
                }
            }
        }
    }

    fun recordSupplierInvoice(supplierId: String, amount: Double, motif: String, ref: String?) {
        val author = uiState.value.currentUser?.name ?: "Gérant"
        viewModelScope.launch {
            val res = repository.recordSupplierInvoice(supplierId, amount, motif, ref, author)
            showMessage("Facture réception ajoutée à la dette usine")
            if (res != null) {
                val (sup, supMov) = res
                runCloudSync(OperationType.WRITE, "users/$currentUserId/suppliers/$supplierId") {
                    firestoreRepo.upsertSupplier(currentUserId, sup)
                    firestoreRepo.createSupplierMovement(currentUserId, supMov)
                }
            }
        }
    }

    // Caisse
    fun addCaisseMovement(type: String, motif: String, montant: Double) {
        val author = uiState.value.currentUser?.name ?: "Gérant"
        val mov = CaisseMovement(
            id = "caisse_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(4)}",
            date = nowIso(),
            type = type,
            motif = motif,
            montant = montant,
            auteur = author
        )
        viewModelScope.launch {
            repository.addCaisseMovement(mov)
            showMessage(if (type == "entree") "Entrée de caisse ajoutée" else "Dépense / Sortie enregistrée")
            runCloudSync(OperationType.CREATE, "users/$currentUserId/caisse_movements/${mov.id}") {
                firestoreRepo.createCaisseMovement(currentUserId, mov)
            }
        }
    }

    fun saveDailyCaisseCount(
        fondOuverture: Double,
        ventesEspecesJour: Double,
        entreesDiversJour: Double,
        sortiesJour: Double,
        theorique: Double,
        compteReel: Double,
        notes: String
    ) {
        val state = uiState.value
        val count = DailyCaisseCount(
            id = "count_${System.currentTimeMillis()}",
            date = nowIso(),
            magasin = state.settings.activeStore,
            auteur = state.currentUser?.name ?: "Gérant",
            fondOuverture = fondOuverture,
            ventesEspecesJour = ventesEspecesJour,
            entreesDiversJour = entreesDiversJour,
            sortiesJour = sortiesJour,
            theorique = theorique,
            compteReel = compteReel,
            ecart = round2(compteReel - theorique),
            notes = notes
        )
        viewModelScope.launch {
            repository.saveDailyCaisseCount(count)
            showMessage("Pointage caisse fin de journée sauvegardé")
            runCloudSync(OperationType.CREATE, "users/$currentUserId/daily_caisse_counts/${count.id}") {
                firestoreRepo.createDailyCaisseCount(currentUserId, count)
            }
        }
    }

    // Users & Settings
    fun saveUser(user: StaffUser) {
        viewModelScope.launch {
            repository.upsertUser(user)
            showMessage("Profil ${user.name} enregistré")
            runCloudSync(OperationType.WRITE, "users/$currentUserId/staff_users/${user.id}") {
                firestoreRepo.upsertStaffUser(currentUserId, user)
            }
        }
    }

    fun deleteUser(userId: String) {
        viewModelScope.launch {
            repository.deleteUser(userId)
            showMessage("Profil supprimé")
            runCloudSync(OperationType.DELETE, "users/$currentUserId/staff_users/$userId") {
                firestoreRepo.deleteStaffUser(currentUserId, userId)
            }
        }
    }

    fun saveStoreInfo(info: StoreInfo) {
        viewModelScope.launch {
            repository.saveStoreInfo(info)
            showMessage("Coordonnées magasin sauvegardées")
            runCloudSync(OperationType.WRITE, "users/$currentUserId/store_info/default") {
                firestoreRepo.saveStoreInfo(currentUserId, info)
            }
        }
    }

    fun saveSettings(settings: AppSettings) {
        viewModelScope.launch {
            repository.saveSettings(settings)
            runCloudSync(OperationType.WRITE, "users/$currentUserId/app_settings/default") {
                firestoreRepo.saveAppSettings(currentUserId, settings)
            }
        }
    }

    fun resetCatalog() {
        viewModelScope.launch {
            val seeded = repository.resetCatalogToDefault()
            showMessage("Catalogue usines réinitialisé")
            runCloudSync(OperationType.WRITE, "users/$currentUserId/products") {
                firestoreRepo.resetProductsCatalog(currentUserId, seeded)
            }
        }
    }

    fun exportAllDataJson(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val json = repository.exportAllDataJson()
            onResult(json)
        }
    }

    fun importAllDataJson(json: String) {
        viewModelScope.launch {
            val ok = repository.importAllDataJson(json)
            showMessage(if (ok) "Sauvegarde restaurée avec succès" else "Erreur : fichier JSON invalide")
            if (ok) {
                runCloudSync(OperationType.WRITE, "users/$currentUserId") {
                    repository.getProductsSnapshot().let { firestoreRepo.resetProductsCatalog(currentUserId, it) }
                    repository.getCustomersSnapshot().forEach { firestoreRepo.upsertCustomer(currentUserId, it) }
                    repository.getSuppliersSnapshot().forEach { firestoreRepo.upsertSupplier(currentUserId, it) }
                    repository.getUsersSnapshot().forEach { firestoreRepo.upsertStaffUser(currentUserId, it) }
                    firestoreRepo.saveStoreInfo(currentUserId, repository.getStoreInfoSnapshot())
                    firestoreRepo.saveAppSettings(currentUserId, repository.getSettingsSnapshot())
                }
            }
        }
    }

    private fun round2(v: Double): Double = (v * 100.0).roundToInt() / 100.0

    private fun nowIso(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }

    private data class CoreBundle(
        val products: List<TileProduct>,
        val invoices: List<Invoice>,
        val customers: List<Customer>,
        val suppliers: List<Supplier>,
        val supMoves: List<SupplierMovement>
    )

    private data class OpsBundle(
        val caisse: List<CaisseMovement>,
        val dailyCounts: List<DailyCaisseCount>,
        val users: List<StaffUser>,
        val notifications: List<DepotNotification>,
        val currentUserId: String?
    )

    private data class SessionBundle(
        val cart: List<CartItem>,
        val freeLines: List<FreeLineItem>,
        val storeInfo: StoreInfo,
        val settings: AppSettings
    )

    private companion object {
        const val TAG = "PosVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
