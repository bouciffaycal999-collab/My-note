package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import com.example.ui.theme.Slate700

fun parseCeramicColor(hex: String): Color {
    return runCatching {
        val clean = hex.trim().removePrefix("#")
        val parsed = when (clean.length) {
            6 -> ("FF$clean").toLong(16)
            8 -> clean.toLong(16)
            else -> 0xFF94A3B8
        }
        Color(parsed)
    }.getOrDefault(Color(0xFF94A3B8))
}

@Composable
fun TileSwatchImage(
    imageUrl: String,
    colorHex: String,
    contentDescription: String,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 12.dp
) {
    val swatchColor = parseCeramicColor(colorHex)
    val shape = RoundedCornerShape(cornerRadius)

    Box(
        modifier = modifier
            .clip(shape)
            .background(swatchColor)
    ) {
        if (imageUrl.isNotBlank()) {
            SubcomposeAsyncImage(
                model = imageUrl,
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                loading = { CeramicSwatchFallback(swatchColor) },
                error = { CeramicSwatchFallback(swatchColor) }
            )
        } else {
            CeramicSwatchFallback(swatchColor)
        }
    }
}

@Composable
private fun CeramicSwatchFallback(baseColor: Color) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(
                    baseColor,
                    baseColor.copy(alpha = 0.78f),
                    Slate700.copy(alpha = 0.25f)
                ),
                start = Offset.Zero,
                end = Offset(size.width, size.height)
            )
        )
        // Subtle ceramic tile joint lines
        val jointColor = Color.White.copy(alpha = 0.28f)
        drawLine(
            color = jointColor,
            start = Offset(size.width * 0.5f, 0f),
            end = Offset(size.width * 0.5f, size.height),
            strokeWidth = 1.5f
        )
        drawLine(
            color = jointColor,
            start = Offset(0f, size.height * 0.5f),
            end = Offset(size.width, size.height * 0.5f),
            strokeWidth = 1.5f
        )
    }
}
