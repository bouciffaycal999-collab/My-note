package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.example.data.model.AppSettings
import com.example.data.model.CaisseMovement
import com.example.data.model.DailyCaisseCount
import com.example.data.model.DepotNotification
import com.example.data.model.PosSeeds
import com.example.data.model.StaffUser
import com.example.data.model.StoreInfo
import com.example.data.model.formatDa
import com.example.data.model.formatM2
import com.example.ui.components.NonImeNumericKeypad
import com.example.ui.components.NumericDisplayField
import com.example.ui.components.applyKeypadInput
import com.example.ui.components.applyKeypadQuickDelta
import com.example.ui.components.dismissKeypadOnTextFocus
import com.example.ui.components.openWhatsApp
import com.example.ui.theme.Amber400
import com.example.ui.theme.Amber500
import com.example.ui.theme.Cyan400
import com.example.ui.theme.Cyan500
import com.example.ui.theme.Emerald400
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Emerald950
import com.example.ui.theme.Rose400
import com.example.ui.theme.Rose500
import com.example.ui.theme.Rose950
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Composable
fun CaisseScreen(
    movements: List<CaisseMovement>,
    dailyCounts: List<DailyCaisseCount>,
    activeStore: String,
    onAddMovement: (type: String, motif: String, montant: Double) -> Unit,
    onSaveDailyCount: (Double, Double, Double, Double, Double, Double, String) -> Unit
) {
    val context = LocalContext.current
    var showMoveType by remember { mutableStateOf<String?>(null) }
    var showPointageDialog by remember { mutableStateOf(false) }

    val solde = remember(movements) { movements.sumOf { if (it.type == "entree") it.montant else -it.montant } }
    val todayPrefix = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val todayMoves = remember(movements) { movements.filter { it.date.startsWith(todayPrefix) } }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = Slate900, border = BorderStroke(1.dp, Slate800)) {
            Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Caisse & Trésorerie", style = MaterialTheme.typography.titleLarge, color = Slate100, fontWeight = FontWeight.Black)
                        Text("Solde Actuel : ${formatDa(solde)}", style = MaterialTheme.typography.titleMedium, color = Emerald400, fontWeight = FontWeight.Black)
                    }
                    Button(
                        onClick = { showPointageDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber500, contentColor = Slate950),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.PointOfSale, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pointage", fontWeight = FontWeight.Black)
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { showMoveType = "entree" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Slate950)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Entrée", fontWeight = FontWeight.Black)
                    }
                    Button(
                        onClick = { showMoveType = "sortie" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Rose500, contentColor = Slate100)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Dépense / Sortie", fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (dailyCounts.isNotEmpty()) {
                item {
                    val last = dailyCounts.first()
                    Surface(shape = RoundedCornerShape(12.dp), color = Slate900, border = BorderStroke(1.dp, Amber500.copy(alpha = 0.5f))) {
                        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Dernier Pointage (${last.date.take(10)})", style = MaterialTheme.typography.labelMedium, color = Amber400)
                                Text("Compté: ${formatDa(last.compteReel)} • Théorique: ${formatDa(last.theorique)}", style = MaterialTheme.typography.bodySmall, color = Slate100)
                            }
                            Text(
                                text = "Écart: ${formatDa(last.ecart)}",
                                color = if (kotlin.math.abs(last.ecart) < 1.0) Emerald400 else Rose400,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
            items(movements, key = { it.id }) { m ->
                Surface(shape = RoundedCornerShape(12.dp), color = Slate900, border = BorderStroke(1.dp, Slate800)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(m.motif, style = MaterialTheme.typography.titleSmall, color = Slate100)
                            Text("${m.date.take(16).replace('T', ' ')} • ${m.auteur}", style = MaterialTheme.typography.labelSmall, color = Slate400)
                        }
                        Text(
                            text = (if (m.type == "entree") "+" else "-") + formatDa(m.montant),
                            style = MaterialTheme.typography.titleMedium,
                            color = if (m.type == "entree") Emerald400 else Rose400,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }
    }

    showMoveType?.let { type ->
        BackHandler { showMoveType = null }
        var amtStr by remember { mutableStateOf("0") }
        var motif by remember { mutableStateOf(if (type == "entree") "Apport Caisse" else "Dépense magasin") }
        var showKeypad by remember { mutableStateOf(true) }
        var isPristine by remember { mutableStateOf(true) }
        Dialog(onDismissRequest = { showMoveType = null }) {
            Surface(modifier = Modifier.fillMaxWidth().widthIn(max = 480.dp), shape = RoundedCornerShape(20.dp), color = Slate900, border = BorderStroke(1.dp, Slate700)) {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(if (type == "entree") "Nouvelle Entrée Caisse" else "Nouvelle Dépense", style = MaterialTheme.typography.titleLarge, color = if (type == "entree") Emerald400 else Rose400, fontWeight = FontWeight.Black)
                        IconButton(onClick = { showMoveType = null }) { Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Slate400) }
                    }
                    NumericDisplayField(label = "Montant (DA)", value = amtStr, isActive = showKeypad, onSelect = { isPristine = true; showKeypad = true }, suffix = "DA")
                    OutlinedTextField(value = motif, onValueChange = { motif = it }, label = { Text("Motif") }, singleLine = true, modifier = Modifier.fillMaxWidth().dismissKeypadOnTextFocus { showKeypad = false })
                    AnimatedVisibility(visible = showKeypad, enter = expandVertically(), exit = shrinkVertically()) {
                        NonImeNumericKeypad(
                            onKeyPress = { k ->
                                val (n, p) = applyKeypadInput(amtStr, k, false, isPristine)
                                amtStr = n; isPristine = p
                            },
                            quickChips = listOf("+500" to 500.0, "+2000" to 2000.0, "+5000" to 5000.0),
                            onQuickDelta = { d -> amtStr = applyKeypadQuickDelta(amtStr, d, false); isPristine = false },
                            allowDecimal = false,
                            onValidate = {
                                val v = amtStr.toDoubleOrNull() ?: 0.0
                                if (v > 0 && motif.isNotBlank()) {
                                    onAddMovement(type, motif.trim(), v)
                                    showMoveType = null
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showPointageDialog) {
        BackHandler { showPointageDialog = false }
        val ventesJour = todayMoves.filter { it.type == "entree" && it.referenceFacture != null }.sumOf { it.montant }
        val entreesDiv = todayMoves.filter { it.type == "entree" && it.referenceFacture == null }.sumOf { it.montant }
        val sortiesJour = todayMoves.filter { it.type == "sortie" }.sumOf { it.montant }
        var compteStr by remember { mutableStateOf(solde.coerceAtLeast(0.0).toInt().toString()) }
        var notes by remember { mutableStateOf("") }
        var showKeypad by remember { mutableStateOf(true) }
        var isPristine by remember { mutableStateOf(true) }
        val compteReel = compteStr.toDoubleOrNull() ?: 0.0
        val ecart = compteReel - solde

        Dialog(onDismissRequest = { showPointageDialog = false }) {
            Surface(modifier = Modifier.fillMaxWidth().widthIn(max = 500.dp), shape = RoundedCornerShape(20.dp), color = Slate900, border = BorderStroke(1.dp, Slate700)) {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Pointage Fin de Journée ($activeStore)", style = MaterialTheme.typography.titleMedium, color = Amber400, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                        IconButton(onClick = { showPointageDialog = false }) { Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Slate400) }
                    }
                    Text("Solde Théorique : ${formatDa(solde)}", style = MaterialTheme.typography.titleSmall, color = Cyan400)
                    NumericDisplayField(label = "Montant Compté Réel", value = compteStr, isActive = showKeypad, onSelect = { isPristine = true; showKeypad = true }, suffix = "DA", accentColor = Emerald400)
                    Text("Écart : ${formatDa(ecart)}", style = MaterialTheme.typography.titleSmall, color = if (kotlin.math.abs(ecart) < 1.0) Emerald400 else Rose400)
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes clôture") }, singleLine = true, modifier = Modifier.fillMaxWidth().dismissKeypadOnTextFocus { showKeypad = false })
                    AnimatedVisibility(visible = showKeypad, enter = expandVertically(), exit = shrinkVertically()) {
                        NonImeNumericKeypad(
                            onKeyPress = { k -> val (n, p) = applyKeypadInput(compteStr, k, false, isPristine); compteStr = n; isPristine = p },
                            allowDecimal = false,
                            onValidate = {
                                onSaveDailyCount(50000.0, ventesJour, entreesDiv, sortiesJour, solde, compteReel, notes)
                                showPointageDialog = false
                            },
                            validateLabel = "Clôturer Caisse"
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            val msg = "💰 *CLÔTURE CAISSE $activeStore*\nThéorique: ${formatDa(solde)}\nCompté: ${formatDa(compteReel)}\nÉcart: ${formatDa(ecart)}"
                            openWhatsApp(context, PosSeeds.WHATSAPP_PATRON, msg)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = Emerald400, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Envoyer Bilan au Patron (WA)", color = Emerald400)
                    }
                }
            }
        }
    }
}

@Composable
fun UsersScreen(
    users: List<StaffUser>,
    currentUser: StaffUser?,
    onSaveUser: (StaffUser) -> Unit,
    onDeleteUser: (String) -> Unit
) {
    var editingUser by remember { mutableStateOf<StaffUser?>(null) }
    var showCreate by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = Slate900, border = BorderStroke(1.dp, Slate800)) {
            Row(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Gestion Équipe & Permissions", style = MaterialTheme.typography.titleLarge, color = Slate100, fontWeight = FontWeight.Black)
                    Text("${users.size} comptes configurés", style = MaterialTheme.typography.bodySmall, color = Cyan400)
                }
                Button(
                    onClick = { showCreate = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Amber500, contentColor = Slate950)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Profil", fontWeight = FontWeight.Black)
                }
            }
        }

        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(users, key = { it.id }) { u ->
                Surface(shape = RoundedCornerShape(14.dp), color = Slate900, border = BorderStroke(1.dp, Slate800)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(u.name, style = MaterialTheme.typography.titleMedium, color = Slate100, fontWeight = FontWeight.Bold)
                            Text("${u.role.uppercase()} • ${u.magasin} • PIN: ${u.pin}", style = MaterialTheme.typography.bodySmall, color = Cyan400)
                            Text("${u.allowedTabs.size} onglets autorisés", style = MaterialTheme.typography.labelSmall, color = Slate400)
                        }
                        Row {
                            OutlinedButton(onClick = { editingUser = u }) { Text("Éditer", color = Amber400) }
                            if (u.id != currentUser?.id && u.id != "u_kader") {
                                IconButton(onClick = { onDeleteUser(u.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Supprimer", tint = Rose400)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreate || editingUser != null) {
        BackHandler { showCreate = false; editingUser = null }
        val init = editingUser
        var name by remember { mutableStateOf(init?.name ?: "") }
        var pinStr by remember { mutableStateOf(init?.pin ?: "0000") }
        var role by remember { mutableStateOf(init?.role ?: "vendeur") }
        var magasin by remember { mutableStateOf(init?.magasin ?: "Depot Remchi") }
        var showKeypad by remember { mutableStateOf(false) }
        var isPristine by remember { mutableStateOf(true) }

        Dialog(onDismissRequest = { showCreate = false; editingUser = null }) {
            Surface(modifier = Modifier.fillMaxWidth().widthIn(max = 480.dp), shape = RoundedCornerShape(20.dp), color = Slate900, border = BorderStroke(1.dp, Slate700)) {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (init == null) "Nouveau Profil Staff" else "Modifier ${init.name}", style = MaterialTheme.typography.titleLarge, color = Amber400, fontWeight = FontWeight.Black)
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth().dismissKeypadOnTextFocus { showKeypad = false })
                    NumericDisplayField(label = "Code PIN (4 chiffres)", value = pinStr, isActive = showKeypad, onSelect = { isPristine = true; showKeypad = true }, accentColor = Amber400)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("admin", "gerant", "vendeur").forEach { r ->
                            FilterChip(selected = role == r, onClick = { role = r; showKeypad = false }, label = { Text(r) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PosSeeds.SITES.forEach { s ->
                            FilterChip(selected = magasin == s, onClick = { magasin = s; showKeypad = false }, label = { Text(s.replace("Magasin ", "Mag ")) })
                        }
                    }
                    AnimatedVisibility(visible = showKeypad, enter = expandVertically(), exit = shrinkVertically()) {
                        NonImeNumericKeypad(
                            onKeyPress = { k -> val (n, p) = applyKeypadInput(pinStr, k, false, isPristine); pinStr = n.take(4); isPristine = p },
                            allowDecimal = false,
                            onValidate = { showKeypad = false },
                            validateLabel = "OK"
                        )
                    }
                    Button(
                        onClick = {
                            if (name.isNotBlank() && pinStr.length == 4) {
                                val isAdmin = role == "admin"
                                val isGerant = role == "gerant" || isAdmin
                                val tabs = when {
                                    isAdmin -> PosSeeds.ALL_TABS
                                    isGerant -> listOf("pos", "stock", "invoices", "dashboard", "customers", "suppliers", "caisse", "settings")
                                    else -> listOf("pos", "stock", "invoices", "customers")
                                }
                                onSaveUser(
                                    StaffUser(
                                        id = init?.id ?: "u_${UUID.randomUUID().toString().take(6)}",
                                        name = name.trim(),
                                        role = role,
                                        pin = pinStr,
                                        magasin = magasin,
                                        allowedTabs = tabs,
                                        canEditInvoices = isGerant,
                                        canDeleteInvoices = isAdmin,
                                        canModifyStock = isGerant,
                                        canViewSuppliers = isGerant,
                                        canViewCaisse = isGerant,
                                        canManageUsers = isAdmin,
                                        active = true
                                    )
                                )
                                showCreate = false; editingUser = null
                            }
                        },
                        enabled = name.isNotBlank() && pinStr.length == 4,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Slate950)
                    ) { Text("Enregistrer Profil", fontWeight = FontWeight.Black) }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    storeInfo: StoreInfo,
    settings: AppSettings,
    firebaseUserEmail: String?,
    isCloudSynced: Boolean,
    cloudSyncError: String?,
    onSignOutGoogle: () -> Unit,
    onSaveStoreInfo: (StoreInfo) -> Unit,
    onSaveSettings: (AppSettings) -> Unit,
    onResetCatalog: () -> Unit,
    onExportJson: ((String) -> Unit) -> Unit,
    onImportJson: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var nom by remember(storeInfo) { mutableStateOf(storeInfo.nom) }
    var adresse by remember(storeInfo) { mutableStateOf(storeInfo.adresse) }
    var tel by remember(storeInfo) { mutableStateOf(storeInfo.tel) }
    var pendingExportJson by remember { mutableStateOf<String?>(null) }
    var isSharingApk by remember { mutableStateOf(false) }
    var shareApkError by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val json = pendingExportJson
        if (uri != null && json != null) {
            context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
        }
        pendingExportJson = null
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (!text.isNullOrBlank()) onImportJson(text)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Paramètres Magasin & Système", style = MaterialTheme.typography.titleLarge, color = Slate100, fontWeight = FontWeight.Black)

        Surface(shape = RoundedCornerShape(16.dp), color = Slate900, border = BorderStroke(1.dp, Slate800)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Compte Google & Cloud Firebase", style = MaterialTheme.typography.titleMedium, color = Cyan400, fontWeight = FontWeight.Bold)
                Text(
                    text = firebaseUserEmail ?: "Compte Google connecté",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Slate100,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = when {
                        cloudSyncError != null -> "Synchronisation : $cloudSyncError"
                        isCloudSynced -> "Cloud Firestore synchronisé en temps réel"
                        else -> "Connexion au Cloud Firestore..."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = when {
                        cloudSyncError != null -> Amber400
                        isCloudSynced -> Emerald400
                        else -> Slate400
                    }
                )
                OutlinedButton(
                    onClick = onSignOutGoogle,
                    modifier = Modifier.fillMaxWidth().testTag("google_sign_out_btn"),
                    border = BorderStroke(1.dp, Rose400.copy(alpha = 0.55f))
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Rose400, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Déconnecter le compte Google", color = Rose400, fontWeight = FontWeight.Bold)
                }
            }
        }

        Surface(shape = RoundedCornerShape(16.dp), color = Slate900, border = BorderStroke(1.dp, Slate800)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Site Actif & Impression", style = MaterialTheme.typography.titleMedium, color = Cyan400, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PosSeeds.SITES.forEach { s ->
                        FilterChip(
                            selected = settings.activeStore == s,
                            onClick = { onSaveSettings(settings.copy(activeStore = s)) },
                            label = { Text(s.replace("Magasin ", "Mag ")) }
                        )
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Masquer Bain/Teinte sur facture", color = Slate100, style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = settings.hideBainTeinteFacture,
                        onCheckedChange = { onSaveSettings(settings.copy(hideBainTeinteFacture = it)) }
                    )
                }
            }
        }

        Surface(shape = RoundedCornerShape(16.dp), color = Slate900, border = BorderStroke(1.dp, Slate800)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Identité Magasin (Factures)", style = MaterialTheme.typography.titleMedium, color = Amber400, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = nom, onValueChange = { nom = it }, label = { Text("Nom commercial") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = adresse, onValueChange = { adresse = it }, label = { Text("Adresse") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = tel, onValueChange = { tel = it }, label = { Text("Téléphone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(
                    onClick = { onSaveStoreInfo(storeInfo.copy(nom = nom, adresse = adresse, tel = tel)) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan500, contentColor = Slate950)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Sauvegarder Coordonnées", fontWeight = FontWeight.Black)
                }
            }
        }

        Surface(shape = RoundedCornerShape(16.dp), color = Slate900, border = BorderStroke(1.dp, Slate800)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Sauvegarde JSON & Catalogue", style = MaterialTheme.typography.titleMedium, color = Emerald400, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            onExportJson { json ->
                                pendingExportJson = json
                                exportLauncher.launch("KADER_CERAMIC_BACKUP.json")
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Slate950)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Exporter", fontWeight = FontWeight.Black)
                    }
                    OutlinedButton(
                        onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = null, tint = Cyan400, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Importer", color = Cyan400)
                    }
                }
                OutlinedButton(
                    onClick = onResetCatalog,
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, Rose400.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null, tint = Rose400, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Réinitialiser Catalogue Usines", color = Rose400)
                }
            }
        }

        Surface(shape = RoundedCornerShape(16.dp), color = Slate900, border = BorderStroke(1.dp, Slate800)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Partager l'application (.apk)", style = MaterialTheme.typography.titleMedium, color = Cyan400, fontWeight = FontWeight.Bold)
                Text(
                    "Envoyez directement le fichier d'installation Kader_POS.apk vers un autre téléphone via WhatsApp, Telegram ou Bluetooth.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate400
                )
                if (shareApkError != null) {
                    Text(
                        text = shareApkError ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = Rose400
                    )
                }
                Button(
                    onClick = {
                        if (isSharingApk) return@Button
                        isSharingApk = true
                        shareApkError = null
                        coroutineScope.launch {
                            val result = runCatching {
                                val apkFile = withContext(Dispatchers.IO) {
                                    val sourcePath = context.applicationInfo.sourceDir
                                        ?: error("Fichier APK introuvable sur cet appareil.")
                                    val sourceApk = File(sourcePath)
                                    if (!sourceApk.exists() || !sourceApk.canRead()) {
                                        error("Impossible de lire le fichier APK installé.")
                                    }
                                    val shareDir = File(context.cacheDir, "shared_apks").apply { mkdirs() }
                                    val targetApk = File(shareDir, "Kader_POS.apk")
                                    sourceApk.copyTo(targetApk, overwrite = true)
                                    targetApk
                                }
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    apkFile
                                )
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/vnd.android.package-archive"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    putExtra(Intent.EXTRA_SUBJECT, "Kader POS (.apk)")
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "Installez Kader POS sur votre téléphone Android en ouvrant le fichier Kader_POS.apk joint."
                                    )
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                val chooserIntent = Intent.createChooser(sendIntent, "Partager Kader POS (.apk)").apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(chooserIntent)
                            }
                            result.onFailure { err ->
                                shareApkError = err.localizedMessage ?: "Impossible de partager l'APK."
                            }
                            isSharingApk = false
                        }
                    },
                    enabled = !isSharingApk,
                    modifier = Modifier.fillMaxWidth().testTag("share_apk_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan500, contentColor = Slate950)
                ) {
                    if (isSharingApk) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = Slate950
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Préparation de Kader_POS.apk...", fontWeight = FontWeight.Black)
                    } else {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Partager Kader_POS.apk", fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsSheet(
    notifications: List<DepotNotification>,
    onDismiss: () -> Unit
) {
    BackHandler { onDismiss() }
    val context = LocalContext.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Slate950,
        contentColor = Slate100
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Notifications, contentDescription = null, tint = Amber400)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Notifications Dépôt (${notifications.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Slate400) }
            }
            HorizontalDivider(color = Slate800)
            if (notifications.isEmpty()) {
                Text("Aucune préparation dépôt en attente.", color = Slate400, style = MaterialTheme.typography.bodyMedium)
            } else {
                LazyColumn(modifier = Modifier.height(400.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(notifications, key = { it.id }) { n ->
                        Surface(shape = RoundedCornerShape(12.dp), color = Slate900, border = BorderStroke(1.dp, Slate800)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("#${n.reference} • ${n.client}", style = MaterialTheme.typography.titleSmall, color = Slate100, fontWeight = FontWeight.Bold)
                                    Text("${n.cartonsTotal} ctn / ${formatM2(n.m2Total)} m²", style = MaterialTheme.typography.labelMedium, color = Cyan400)
                                }
                                Text(n.articlesSummary, style = MaterialTheme.typography.bodySmall, color = Slate400)
                                Button(
                                    onClick = {
                                        val msg = "📦 *ALERTE DÉPÔT #${n.reference}*\nClient: ${n.client}\n${n.articlesSummary}"
                                        openWhatsApp(context, PosSeeds.WHATSAPP_DEPOT, msg)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Slate950)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Alerter Dépôt (WhatsApp)", fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
